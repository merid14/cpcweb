 
 
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

  <title>New Here</title>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <meta name="description" content="A small sentence describing your ministry and this page." />
  <meta name="keywords" content="some, keywords, separated, by, comas" />
  <meta name="Robots" content="index, follow" />
        
    <!-- Favicon -->
  <link href="favicon.ico" type="image/x-icon" rel="shortcut icon">
    
    <!-- Include CSS -->
     
</head>
<body class="home">  
      
      <!-- Include Logo and Menu -->
            
        <div id="content" class="home">
        
          <div id="slider">
            <div class="wrap">
            	
            	<div class="c-12">
            	
            	
            	<div class="maskContent_long"></div>
            	<div id="long-slider">
            	
                 
                    <ul id="slideshow-long">
                        <li class="cms-repeat" id="banner-rotator"><a id="ee3779" class="cms-editable"></a><img id="e6ca51" class="cms-editable" src="/cms-assets/zoom-cropped-images/649834_1_e6ca51.png?rand=0.13595633997128303" alt="" width="950" height="150" /></li>
                        
                    </ul>
                   
                </div>
                
                </div>
                   <div class="page2">
                        <h1 class="cms-editable" id="banner-answer"><strong>&nbsp;</strong></h1>
                                
                        <div class="cms-repeat" id="text-large">
<div class="cms-editable" id="text-large-content">
<p style="text-align: center;"><span style="color: #00ffff;"><strong><span style="font-size: x-large;"><span style="color: #33cccc;">VISION</span></span></strong></span></p>
<p style="text-align: center;"><span style="font-size: large;">Getting Connected...Changing Lives...Building Community...One Life At A Time!</span></p>
<p style="text-align: center;"><span style="color: #33cccc;"><strong><span style="font-size: x-large;">MISSION</span></strong></span></p>
<p style="text-align: center;"><span style="font-size: large;">Connection Point Church exists to CONNECT people into a life transforming relationship with Jesus.</span></p>
<p style="text-align: center;"><span style="color: #33cccc;"><strong><span style="font-size: x-large;">CORE VALUES</span></strong></span></p>
<p style="text-align: center;"><span style="font-size: large;">We Believe:</span></p>
<p style="text-align: center;"><span style="font-size: large;">Connected people CONNECT with people</span></p>
<p style="text-align: center;"><span style="font-size: large;">Transforming people CHANGE</span></p>
<p style="text-align: center;"><span style="font-size: large;">Changed people SERVE</span></p>
<p style="text-align: center;"><span style="font-size: large;">Building community IS doing life together</span></p>
<p style="text-align: center;"><span style="font-size: large;">You CANNOT out give God</span></p>
</div>
</div>
                
             </div>   <!-- end page -->
               
      </div><!-- end wrap -->
            </div><!-- end slider -->
            
           
 
        </div><!-- end content -->
        
        <!-- Include Footer -->
        
     <!-- Include Google Tracker -->
    

</body>
</html>
