 
 
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

  <title>Stuck?</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <meta name="description" content="Stuck?, a sermon series of Connection Point Church | Barbourville, KY" />
  <meta name="keywords" content="Stuck, Connection Point Church, Barbourville, KY" />
  <meta name="Robots" content="index, follow" />
        
    <!-- Favicon -->
  <link href="favicon.ico" type="image/x-icon" rel="shortcut icon">
    
    <!-- Include CSS 
        
</head>


<body class="home">  
    
    <!-- Include Logo and Menu -->
            
        
        
        <div id="content">
        
          <div class="wrap">
              <div class="c-8 divider">
              
<script type="text/javascript"> 
	
	var currentPlayer;
	$(function(){
	
	$('.play').click(function() {
		$('.player').hide();
		player_div = $(this).attr('rel');
		container = $('#'+player_div);
		container.fadeIn();
		player =  $('#'+player_div+' audio');
		player.attr('src',$(this).attr('href'));
		
		try {
			player.mediaelementplayer({
				audioWidth:container.width(),
				success:function(mediaElement,domObject) {
					mediaElement.play();
					currentPlayer = mediaElement;
				}
			});
			
		} catch(e) {
			
		}
		return false;
  });
  $('.dload').each(function () { var href = $(this).attr('href'); $(this).attr('href', 'download.php?f=' + href); });
  $('.play').each(function(){
      $(this).attr("rel",$(this).closest('.message_buttons').next('.audio_player').attr('id'));
  });

  });
  $(function() {
    var links = $('.message_sharing a'),
        matchExp = /\[PAGEURL\]/,
        currentURL = location.href;

    links.each(function() {
        var currentHREF = $(this).attr('href');
        if (currentHREF.match(matchExp)) {
            $(this).attr('href',currentHREF.replace(matchExp,currentURL));
        }
    });

}); 
</script>

<div class="message_archive">
			<div class="message_archive_message">
			<div class="message_series_image" id="series-image"><img id="e9135b" class="cms-editable" src="/cms-assets/zoom-cropped-images/611462_26_e9135b.jpg?rand=0.799968427525035" alt="" width="595" height="280" /></div>
			<div class="message_details">
				<div><h1 class="message_title cms-editable" id="title">STUCK</h1></div>
				<div class="series_description cms-editable-text" id="Series_desc">Our lives get stuck sometimes. The problem is that when it does we seem to quickly develope an attitude of "why bother" or "what's the point?" We settle for the hand that has been delt because life has not been going the way that we want it to and we find ourselves STUCK! If you really want to know why you SHOULD bother...listen to this series!</div>
	

			</div><!-- end message_details-->
			</div><!-- message_archive_message -->
		</div><!-- message_archive -->
		
		
		
              


		<div class="message_archive cms-repeat" id="message-repeat">
<div class="message_archive_message">
<div class="media">
<h4 id="info" class="message_info cms-editable"><strong>STUCK- Week 1 Coming soon</strong><br />02-07-2016, Pastor Jeremiah Evans</h4>
<div class="message_description cms-editable" id="desc">
<p>God's Plan&gt;What We Settle For</p>
</div>
<div class="message_buttons">
<div class="message_sharing">
<ul class="message_sharing_links">
<li class="greyback_primary message_sharing_share">Share:</li>
<li class="message_sharing_facebook greyback_primary_accent"><a href="http://www.facebook.com/sharer.php?u=[PAGEURL]" target="_blank">F</a></li>
<li class="message_sharing_twitter greyback_primary_accent"><a href="http://twitter.com/home?status=[PAGEURL]" target="_blank">T</a></li>
<li class="message_sharing_email greyback_primary_accent"><a href="mailto:?">E</a></li>
</ul>
</div>
<div class="message_controls">
<ul class="message_control_links">
<li id="listen" class="message_control_listen greyback_primary_accent cms-editable"><a class="play" href="media/020716stuck.mp3"><img id="edc440" src="css/media/listen.jpg" alt="" width="79" height="24" /></a></li>
<li id="download" class="message_control_download greyback_primary_accent cms-editable"><a class="dload" href="media/020716stuck.mp3"><img id="e18729" src="css/media/download.jpg" alt="" width="98" height="24" /><img id="ede3fe" src="/cms-assets/images/584611.notes.jpg" alt="" width="81" height="24" /></a></li>
</ul>
</div>
</div>
<div class="audio_player" id="play1243"><audio controls="controls"></audio></div>
</div>
<!-- end media --></div>
<!-- message_archive_message --></div><!-- message_archive -->
		</div><!-- end c-8-->
            
                <div class="c-4 sidebar">
                    
                    <div class="widget widget-news-events">
                        
                        <h3 class="widget-title cms-editable" id="events-title">&nbsp;</h3>
                        <ul>
                            <li class="cms-repeat" id="events-repeat">
<h3 id="event-heading" class="title cms-editable"><a href="gameplan.php">&nbsp;</a></h3>
<div class="excerpt" id="event-content-div">
<p id="event-content" class="cms-editable">&nbsp;</p>
</div>
</li>
                            
                        </ul>
                        
                    </div><!-- end widget-news-events-->                       
                </div><!-- end sidebar -->
            </div><!-- end wrap -->
        </div><!-- end content -->
        
    <!-- Include Footer -->
        
    <!-- Include Google Tracker -->
         
	<script type="text/javascript" src="css/media/mediaelement-and-player.min.js"></script>
</body>
</html>
