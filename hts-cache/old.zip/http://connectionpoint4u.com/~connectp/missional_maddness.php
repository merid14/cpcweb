 
 
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

  <title>Missional Madness</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <meta name="description" content="Missional Madness, a sermon series of Connection Point Church | Barbourville, KY" />
  <meta name="keywords" content="Missional Madness, Connection Point Church, Barbourville, KY" />
  <meta name="Robots" content="index, follow" />
        
    <!-- Favicon -->
  <link href="favicon.ico" type="image/x-icon" rel="shortcut icon">
    
    <!-- Include CSS 
        
</head>


<body class="home">  
    
    <!-- Include Logo and Menu -->
            
        
        
        <div id="content">
        
          <div class="wrap">
              <div class="c-8 divider">
              
<script type="text/javascript"> 
	
	var currentPlayer;
	$(function(){
	
	$('.play').click(function() {
		$('.player').hide();
		player_div = $(this).attr('rel');
		container = $('#'+player_div);
		container.fadeIn();
		player =  $('#'+player_div+' audio');
		player.attr('src',$(this).attr('href'));
		
		try {
			player.mediaelementplayer({
				audioWidth:container.width(),
				success:function(mediaElement,domObject) {
					mediaElement.play();
					currentPlayer = mediaElement;
				}
			});
			
		} catch(e) {
			
		}
		return false;
  });
  $('.dload').each(function () { var href = $(this).attr('href'); $(this).attr('href', 'download.php?f=' + href); });
  $('.play').each(function(){
      $(this).attr("rel",$(this).closest('.message_buttons').next('.audio_player').attr('id'));
  });

  });
  $(function() {
    var links = $('.message_sharing a'),
        matchExp = /\[PAGEURL\]/,
        currentURL = location.href;

    links.each(function() {
        var currentHREF = $(this).attr('href');
        if (currentHREF.match(matchExp)) {
            $(this).attr('href',currentHREF.replace(matchExp,currentURL));
        }
    });

}); 
</script>

<div class="message_archive">
			<div class="message_archive_message">
			<div class="message_series_image" id="series-image"><img id="e9135b" class="cms-editable" src="/cms-assets/images/233764.mmlarge.jpg?rand=0.14199576908061795" alt="" width="595" height="280" /></div>
			<div class="message_details">
				<div><h1 class="message_title cms-editable" id="title">Missional Madness</h1></div>
				<div class="series_description cms-editable-text" id="Series_desc"><span class="null">Are you ready to take your faith to a whole new level? Are you ready to be a part of something GREAT...much bigger then you could imagine? This series is all about leading us to live a life full of MISSIONAL MADNESS!!!</span></div>
	

			</div><!-- end message_details-->
			</div><!-- message_archive_message -->
		</div><!-- message_archive -->
		
		
		
              


		<div class="message_archive cms-repeat" id="message-repeat">
<div class="message_archive_message">
<div class="media">
<h4 id="info" class="message_info cms-editable"><strong><span class="_5yl5" data-reactid=".dr.$mid=11427069127075=259ab8546b8b2cf7f84.2:0.0.0.0.0"><span data-reactid=".dr.$mid=11427069127075=259ab8546b8b2cf7f84.2:0.0.0.0.0.0">LIVE-IT</span></span>!!!</strong><br />3-29-2015, Paul and Terri Danis</h4>
<div class="message_description cms-editable" id="desc">
<p>Paul and Terri Danis share their heart for Live-It Ministries and the role of Connection Point Church in their community.&nbsp;&nbsp;</p>
</div>
<div class="message_buttons">
<div class="message_sharing">
<ul class="message_sharing_links">
<li class="greyback_primary message_sharing_share">Share:</li>
<li class="message_sharing_facebook greyback_primary_accent"><a href="http://www.facebook.com/sharer.php?u=[PAGEURL]" target="_blank">F</a></li>
<li class="message_sharing_twitter greyback_primary_accent"><a href="http://twitter.com/home?status=[PAGEURL]" target="_blank">T</a></li>
<li class="message_sharing_email greyback_primary_accent"><a href="mailto:?">E</a></li>
</ul>
</div>
<div class="message_controls">
<ul class="message_control_links">
<li id="listen" class="message_control_listen greyback_primary_accent cms-editable"><a class="play" href="media/Paul-Live-It_3-29-2015_final.mp3"><img id="edc440" src="css/media/listen.jpg" alt="" width="79" height="24" /></a></li>
<li id="download" class="message_control_download greyback_primary_accent cms-editable"><a class="dload" href="media/Paul-Live-It_3-29-2015_final.mp3"><img id="e18729" src="css/media/download.jpg" alt="" width="98" height="24" /></a></li>
</ul>
</div>
</div>
<div class="audio_player" id="play1243"><audio controls="controls"></audio></div>
</div>
<!-- end media --></div>
<!-- message_archive_message --></div><div class="message_archive cms-repeat cms-previous-repeat-item-id-message-repeat" id="e12926">
<div class="message_archive_message">
<div class="media">
<h4 id="ea69ac" class="message_info cms-editable"><strong><span class="_5yl5" data-reactid=".dr.$mid=11427069127075=259ab8546b8b2cf7f84.2:0.0.0.0.0"><span data-reactid=".dr.$mid=11427069127075=259ab8546b8b2cf7f84.2:0.0.0.0.0.0">GENEROSITY IS A LIFESTYLE</span></span>!!!</strong><br />3-22-2015, Pastor Jeremiah Evans</h4>
<div class="message_description cms-editable" id="ef3e78">
<p><span class="null"><span class="null"><span class="_5yl5" data-reactid=".dr.$mid=11427069115543=259ab8546b669474d65.2:0.0.0.0.0"><span data-reactid=".dr.$mid=11427069115543=259ab8546b669474d65.2:0.0.0.0.0.0">Its bold but it's true: It is impossible to become a fully developed follower of Jesus without also becoming a fully developed steward of your resources! Stewardship is discipleship! Listen in and learn how to utilize generosity as a measuring tool to know where you are in your walk with Christ.</span></span></span></span></p>
</div>
<div class="message_buttons">
<div class="message_sharing">
<ul class="message_sharing_links">
<li class="greyback_primary message_sharing_share">Share:</li>
<li class="message_sharing_facebook greyback_primary_accent"><a href="http://www.facebook.com/sharer.php?u=[PAGEURL]" target="_blank">F</a></li>
<li class="message_sharing_twitter greyback_primary_accent"><a href="http://twitter.com/home?status=[PAGEURL]" target="_blank">T</a></li>
<li class="message_sharing_email greyback_primary_accent"><a href="mailto:?">E</a></li>
</ul>
</div>
<div class="message_controls">
<ul class="message_control_links">
<li id="e18d10" class="message_control_listen greyback_primary_accent cms-editable"><a class="play" href="media/Pastor-Jeremiah_3-22-2015_final.mp3"><img id="e87869" src="css/media/listen.jpg" alt="" width="79" height="24" /></a></li>
<li id="e7e075" class="message_control_download greyback_primary_accent cms-editable"><a class="dload" href="media/Pastor-Jeremiah_3-22-2015_final.mp3"><img id="e7f1ce" src="css/media/download.jpg" alt="" width="98" height="24" /></a></li>
</ul>
</div>
</div>
<div class="audio_player" id="e81583"><audio controls="controls"></audio></div>
</div>
<!-- end media --></div>
<!-- message_archive_message --></div><div class="message_archive cms-repeat cms-previous-repeat-item-id-message-repeat" id="e556e3">
<div class="message_archive_message">
<div class="media">
<h4 id="ee54e6" class="message_info cms-editable"><strong>Discipline!!!</strong><br />3-15-2015, Pastor Jeremiah Evans</h4>
<div class="message_description cms-editable" id="e5e1de">
<p><span class="null"><span class="null">The greatest of champions don't succeed by desire, but rather by having great amounts of discipline. Discipline is the difference maker between living an average life vs. living an abundant life.</span></span></p>
</div>
<div class="message_buttons">
<div class="message_sharing">
<ul class="message_sharing_links">
<li class="greyback_primary message_sharing_share">Share:</li>
<li class="message_sharing_facebook greyback_primary_accent"><a href="http://www.facebook.com/sharer.php?u=[PAGEURL]" target="_blank">F</a></li>
<li class="message_sharing_twitter greyback_primary_accent"><a href="http://twitter.com/home?status=[PAGEURL]" target="_blank">T</a></li>
<li class="message_sharing_email greyback_primary_accent"><a href="mailto:?">E</a></li>
</ul>
</div>
<div class="message_controls">
<ul class="message_control_links">
<li id="ee39d7" class="message_control_listen greyback_primary_accent cms-editable"><a class="play" href="media/Pastor-Jeremiah_3-15-2015_final.mp3"><img id="e7b09" src="css/media/listen.jpg" alt="" width="79" height="24" /></a></li>
<li id="e7e0a4" class="message_control_download greyback_primary_accent cms-editable"><a class="dload" href="media/Pastor-Jeremiah_3-15-2015_final.mp3"><img id="e55bef" src="css/media/download.jpg" alt="" width="98" height="24" /></a></li>
</ul>
</div>
</div>
<div class="audio_player" id="ec6d9e"><audio controls="controls"></audio></div>
</div>
<!-- end media --></div>
<!-- message_archive_message --></div><div class="message_archive cms-repeat cms-previous-repeat-item-id-message-repeat" id="e80947">
<div class="message_archive_message">
<div class="media">
<h4 id="e21280" class="message_info cms-editable"><strong>THERE IS A PLAN TO CAN THE MISSION!!! </strong><br />3-1-2015, Pastor Jeremiah Evans</h4>
<div class="message_description cms-editable" id="e8b2fb">
<p><span class="null">Making disciples is the mission and God is not afraid to use it!! Are you?? Knowing what God's ultimate mission is and what role you play in it will radically change how you do life and what you focus on!!</span></p>
</div>
<div class="message_buttons">
<div class="message_sharing">
<ul class="message_sharing_links">
<li class="greyback_primary message_sharing_share">Share:</li>
<li class="message_sharing_facebook greyback_primary_accent"><a href="http://www.facebook.com/sharer.php?u=[PAGEURL]" target="_blank">F</a></li>
<li class="message_sharing_twitter greyback_primary_accent"><a href="http://twitter.com/home?status=[PAGEURL]" target="_blank">T</a></li>
<li class="message_sharing_email greyback_primary_accent"><a href="mailto:?">E</a></li>
</ul>
</div>
<div class="message_controls">
<ul class="message_control_links">
<li id="e9d4" class="message_control_listen greyback_primary_accent cms-editable"><a class="play" href="media/Pastor-Jeremiah_3-1-2015_final.mp3"><img id="e47fa1" src="css/media/listen.jpg" alt="" width="79" height="24" /></a></li>
<li id="e13cb8" class="message_control_download greyback_primary_accent cms-editable"><a class="dload" href="media/Pastor-Jeremiah_3-1-2015_final.mp3"><img id="ed0b5f" src="css/media/download.jpg" alt="" width="98" height="24" /></a></li>
</ul>
</div>
</div>
<div class="audio_player" id="e3c244"><audio controls="controls"></audio></div>
</div>
<!-- end media --></div>
<!-- message_archive_message --></div><!-- message_archive -->
		</div><!-- end c-8-->
            
                <div class="c-4 sidebar">
                    
                    <div class="widget widget-news-events">
                        
                        <h3 class="widget-title cms-editable" id="events-title">&nbsp;</h3>
                        <ul>
                            <li class="cms-repeat" id="events-repeat">
<h3 id="event-heading" class="title cms-editable"><a href="gameplan.php">&nbsp;</a></h3>
<div class="excerpt" id="event-content-div">
<p id="event-content" class="cms-editable">&nbsp;</p>
</div>
</li>
                            
                        </ul>
                        
                    </div><!-- end widget-news-events-->                       
                </div><!-- end sidebar -->
            </div><!-- end wrap -->
        </div><!-- end content -->
        
    <!-- Include Footer -->
        
    <!-- Include Google Tracker -->
         
	<script type="text/javascript" src="css/media/mediaelement-and-player.min.js"></script>
</body>
</html>
