 
 
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

  <title>21 Days of Prayer and Fasting</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <meta name="description" content="Prayer has a tendency to be that thing we do when we find ourselves in times of crisis! Why not make it a lifestyle!" />
  <meta name="keywords" content="21, days, of, prayer, and, fasting, series, in, march, connection, point, church" />
  <meta name="Robots" content="index, follow" />
        
    <!-- Favicon -->
  <link href="favicon.ico" type="image/x-icon" rel="shortcut icon">
    
    <!-- Include CSS 
    <!-- DNS Prefetch -->
	<link rel="dns-prefetch" href="//ajax.googleapis.com">
	<link rel="dns-prefetch" href="//fonts.googleapis.com">
	<link rel="dns-prefetch" href="//cdn.mybridgeelement.com">

<!-- Design CSS -->
	<link rel="stylesheet" type="text/css" media="screen" href="http://cdn.mybridgeelement.com/_cornerstone/main.css" />
	<link rel="stylesheet" type="text/css" media="screen" href="http://cdn.mybridgeelement.com/_cornerstone/media.css" />
	<link rel="stylesheet" type="text/css" media="screen" href="http://cdn.mybridgeelement.com/_cornerstone/media/mediaelementplayer.min.css" />
	<link rel="stylesheet" type="text/css" media="screen" href="css/style.css" />
	<link rel="stylesheet" type="text/css" media="screen" href="/css/style.css" />
	<link href='http://fonts.googleapis.com/css?family=PT+Sans+Narrow:700' rel='stylesheet' type='text/css'>
	<link href='http://fonts.googleapis.com/css?family=Reenie+Beanie' rel='stylesheet' type='text/css'>
    
<!-- Scripts -->
	<script src="//ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
	<script>window.jQuery || document.write('<script src="js/jquery-1.6.2.min.js"><\/script>')</script>
	<!-- CMS:REMOVE -->
	<script type="text/javascript" src="http://cdn.mybridgeelement.com/js/jCarouselLite.js"></script>
	<script type="text/javascript" src="http://cdn.mybridgeelement.com/js/jquery.innerfade.js"></script>
	<!-- CMS:END-REMOVE -->
	<script type="text/javascript" src="http://cdn.mybridgeelement.com/js/main_cornerstone.js"></script> 
	<script type="text/javascript" src="http://cdn.mybridgeelement.com/js/modernizr-2.0.6.min.js"></script> 
 
<!-- Disqus ID -->


<!-- Folder Links -->
<script type="text/javascript">
var folder = 'public_html';
</script>
<script type="text/javascript">
if(folder != 'public_html') {
$(function() {
   $('a:not([href*=":"])').each(function() {
       var href = $(this).attr('href');
       $(this).attr('href', '../' + href);  
   });
});
}
</script>

<!-- Image Links -->
<script type="text/javascript">
$(function() {
$('.tag .each(function() {
   $('img .each(function() {
       var href = $(this).attr('href');
       $(this).attr('href', '(dynRoot()' + href);  
   });
  }); 
});
</script>    
</head>


<body class="home">  
    
    <!-- Include Logo and Menu -->
    <div id="topbar"></div>
<div id="header">
	
            <div class="wrap">
            
                <h1 class="logo">
                    <a href="index.php">
                        <img src="/cms-assets/zoom-cropped-images/464535_165_logo-image.png?rand=0.27698214851389014" class="cms-editable" id="logo-image" width="400" height="101"  alt="" />
                    </a>
                </h1>
                
                <h3 class="header-title cms-editable" id="header-title"><span style="color: #00ff00;"><strong><br />Getting Connected&hellip;<br />Changing Lives...<br />Building Community...<br />One Life At A Time!!!<br /></strong></span> <script type="text/javascript">// <![CDATA[
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-96551914-1', 'auto');
  ga('send', 'pageview');
// ]]></script></h3>
                <div class="cms-navigation" id="main-navigation">                        <ul class="dd-menu"> 
<li>
<a href="index.php" class="dd-submenu-title">HOME</a>
</li>
<li>
<a href="#" class="dd-submenu-title">NEW HERE</a>
<ul>

<li class="arrow"></li>
<li><a href="whattoexpect.php">Sunday Service</a></li>
<li><a href="staff.php">Leadership</a></li>
<li><a href="beliefs.php">Beliefs</a></li>
<li><a href="location2014.php">Location</a></li>
<li><a href="/kids.php">Kids</a></li>
<li><a href="/~connectp/smallgroups.php">Connect Groups</a></li>
<li><a href="vision.php">Vision and Values</a></li>
</ul>
</li>
<li>
<a href="#" class="dd-submenu-title">NEXT STEPS</a>
<ul>

<li class="arrow"></li>
<li><a href="smallgroups.php">Connect Groups</a></li>
<li><a href="salvation.php">Salvation</a></li>
<li><a href="baptism.php">Baptism</a></li>
<li><a href="/~connectp/serving.php">Serving</a></li>
</ul>
</li>
<li>
<a href="media.php" class="dd-submenu-title">MEDIA</a>
</li>
<li>
<a href="contactpage.php" class="dd-submenu-title">CONTACT US</a>
</li>
<li>
<a href="http://www.mybridgeelementgiving.com/dl/?uid=connpob296" class="dd-submenu-title">GIVE</a>
</li>
<li>
<a href="/~connectp/takesonetonoone.php" class="dd-submenu-title">LISTEN NOW!</a>
</li>
</ul>

                    </div><!-- end main-navigation-->                
                

            </div><!-- end wrap -->
</div><!-- end header -->        
        
        
        <div id="content">
        
          <div class="wrap">
              <div class="c-8 divider">
              
<script type="text/javascript"> 
	
	var currentPlayer;
	$(function(){
	
	$('.play').click(function() {
		$('.player').hide();
		player_div = $(this).attr('rel');
		container = $('#'+player_div);
		container.fadeIn();
		player =  $('#'+player_div+' audio');
		player.attr('src',$(this).attr('href'));
		
		try {
			player.mediaelementplayer({
				audioWidth:container.width(),
				success:function(mediaElement,domObject) {
					mediaElement.play();
					currentPlayer = mediaElement;
				}
			});
			
		} catch(e) {
			
		}
		return false;
  });
  $('.dload').each(function () { var href = $(this).attr('href'); $(this).attr('href', 'download.php?f=' + href); });
  $('.play').each(function(){
      $(this).attr("rel",$(this).closest('.message_buttons').next('.audio_player').attr('id'));
  });

  });
  $(function() {
    var links = $('.message_sharing a'),
        matchExp = /\[PAGEURL\]/,
        currentURL = location.href;

    links.each(function() {
        var currentHREF = $(this).attr('href');
        if (currentHREF.match(matchExp)) {
            $(this).attr('href',currentHREF.replace(matchExp,currentURL));
        }
    });

}); 
</script>

<div class="message_archive">
			<div class="message_archive_message">
			<div class="message_series_image" id="series-image"><img id="e9135b" class="cms-editable" src="/cms-assets/zoom-cropped-images/654568_1_e9135b.jpg?rand=0.6869098044813624" alt="" width="595" height="280" /></div>
			<div class="message_details">
				<div><h1 class="message_title cms-editable" id="title">21 DAYS OF PRAYER AND FASTING</h1></div>
				<div class="series_description cms-editable-text" id="Series_desc">Prayer has a tendancy to be that thing we do when we find ourselves in times of crisis! However, Jesus Himself made it a huge part of His life. Join us as we spend the next 21 days intentionally seeking God together! Why not make prayer a lifestyle and experience the Peace that God has for us!</div>
	

			</div><!-- end message_details-->
			</div><!-- message_archive_message -->
		</div><!-- message_archive -->
		
		
		
              


		<div class="message_archive cms-repeat" id="message-repeat">
<div class="message_archive_message">
<div class="media">
<h4 id="info" class="message_info cms-editable"><strong>Prayer &nbsp;Week One</strong><br />03/06/16, Pastor Jeremiah</h4>
<div class="message_description cms-editable" id="desc">
<p>This disciples heard something in the way that Jesus prayed that they wanted. So...they asked Jesus how to pray. Maybe the primary reason we do not pray is because lack of knowing how.</p>
</div>
<div class="message_buttons">
<div class="message_sharing">
<ul class="message_sharing_links">
<li class="greyback_primary message_sharing_share">Share:</li>
<li class="message_sharing_facebook greyback_primary_accent"><a href="http://www.facebook.com/sharer.php?u=[PAGEURL]" target="_blank">F</a></li>
<li class="message_sharing_twitter greyback_primary_accent"><a href="http://twitter.com/home?status=[PAGEURL]" target="_blank">T</a></li>
<li class="message_sharing_email greyback_primary_accent"><a href="mailto:?">E</a></li>
</ul>
</div>
<div class="message_controls">
<ul class="message_control_links">
<li id="listen" class="message_control_listen greyback_primary_accent cms-editable"><a class="play" href="media/030616prayer.mp3"><img id="e559e4" src="css/media/listen.jpg" alt="" width="79" height="24" /></a></li>
<li id="download" class="message_control_download greyback_primary_accent cms-editable"><a class="dload" href="media/030616prayer.mp3"><img id="e2cda8" src="css/media/download.jpg" alt="" width="98" height="24" /></a><img id="ed38f" src="css/media/notes.jpg" alt="" width="81" height="24" /></li>
</ul>
</div>
</div>
<div class="audio_player" id="play1243"><audio controls="controls"></audio></div>
</div>
<!-- end media --></div>
<!-- message_archive_message --></div><div class="message_archive cms-repeat cms-previous-repeat-item-id-message-repeat" id="e6b60d">
<div class="message_archive_message">
<div class="media">
<h4 id="ee092c" class="message_info cms-editable"><strong>Prayer &nbsp;Week Two</strong><br />03/13/16, Pastor Jeremiah</h4>
<div class="message_description cms-editable" id="e6a777">
<p>If we could pray just one thing as a church what would, or should, it be? God...make us dangerous!! If God would make us dangerous as a church then the ultimate goal would be a transformed world all around us! However, if God is going to MAKE US DANGEROUS, then there are action steps we must take to Walk with Jesus, Listen to Jesus, and live like we Believe in Jesus! A church who lives this out is a church that believes the best is still to come and becomes dangerous!</p>
</div>
<div class="message_buttons">
<div class="message_sharing">
<ul class="message_sharing_links">
<li class="greyback_primary message_sharing_share">Share:</li>
<li class="message_sharing_facebook greyback_primary_accent"><a href="http://www.facebook.com/sharer.php?u=[PAGEURL]" target="_blank">F</a></li>
<li class="message_sharing_twitter greyback_primary_accent"><a href="http://twitter.com/home?status=[PAGEURL]" target="_blank">T</a></li>
<li class="message_sharing_email greyback_primary_accent"><a href="mailto:?">E</a></li>
</ul>
</div>
<div class="message_controls">
<ul class="message_control_links">
<li id="e478b1" class="message_control_listen greyback_primary_accent cms-editable"><a class="play" href="media/031316prayer.mp3"><img id="ec8b6a" src="css/media/listen.jpg" alt="" width="79" height="24" /></a></li>
<li id="eec6ba" class="message_control_download greyback_primary_accent cms-editable"><a class="dload" href="media/031316prayer.mp3"><img id="ecc255" src="css/media/download.jpg" alt="" width="98" height="24" /></a><img id="eab59b" src="css/media/notes.jpg" alt="" width="81" height="24" /></li>
</ul>
</div>
</div>
<div class="audio_player" id="e3c631"><audio controls="controls"></audio></div>
</div>
<!-- end media --></div>
<!-- message_archive_message --></div><div class="message_archive cms-repeat cms-previous-repeat-item-id-e6b60d" id="eddfe4">
<div class="message_archive_message">
<div class="media">
<h4 id="e4a938" class="message_info cms-editable"><strong>Prayer &nbsp;Week Three<br /></strong>03/20/16, Pastor Jeremiah</h4>
<div class="message_description cms-editable" id="e914b1">
<p>Let's pray that we would begin to see our lives through God's perspective; with purpose and a plan. Let's pray that through God's strength we might reach our full potential of living out the purpose God has for us!</p>
</div>
<div class="message_buttons">
<div class="message_sharing">
<ul class="message_sharing_links">
<li class="greyback_primary message_sharing_share">Share:</li>
<li class="message_sharing_facebook greyback_primary_accent"><a href="http://www.facebook.com/sharer.php?u=[PAGEURL]" target="_blank">F</a></li>
<li class="message_sharing_twitter greyback_primary_accent"><a href="http://twitter.com/home?status=[PAGEURL]" target="_blank">T</a></li>
<li class="message_sharing_email greyback_primary_accent"><a href="mailto:?">E</a></li>
</ul>
</div>
<div class="message_controls">
<ul class="message_control_links">
<li id="e4f4c9" class="message_control_listen greyback_primary_accent cms-editable"><a class="play" href="media/032016prayer.mp3"><img id="e29ff" src="css/media/listen.jpg" alt="" width="79" height="24" /></a></li>
<li id="ed5312" class="message_control_download greyback_primary_accent cms-editable"><a class="dload" href="media/032016prayer.mp3"><img id="ef228f" src="css/media/download.jpg" alt="" width="98" height="24" /></a><img id="e60959" src="css/media/notes.jpg" alt="" width="81" height="24" /></li>
</ul>
</div>
</div>
<div class="audio_player" id="e5b01e"><audio controls="controls"></audio></div>
</div>
<!-- end media --></div>
<!-- message_archive_message --></div><div class="message_archive cms-repeat cms-previous-repeat-item-id-eddfe4" id="e3d48c">
<div class="message_archive_message">
<div class="media">
<h4 id="e3c3d5" class="message_info cms-editable"><strong>Easter Day Service<br /></strong>03/27/16, Pastor Jeremiah</h4>
<div class="message_description cms-editable" id="edc7dd">
<p>Easter is a time to celebrate the Resurrection, BUT it is also a time to reflect on the fact the God KNOWS every burden you carry, every sorrow you hurt with, every mistake you have made, and HE KNOWS your greatest need! That need cannot be filled with the many things we attempt to fill it with, but rather our greatest need is Jesus!</p>
</div>
<div class="message_buttons">
<div class="message_sharing">
<ul class="message_sharing_links">
<li class="greyback_primary message_sharing_share">Share:</li>
<li class="message_sharing_facebook greyback_primary_accent"><a href="http://www.facebook.com/sharer.php?u=[PAGEURL]" target="_blank">F</a></li>
<li class="message_sharing_twitter greyback_primary_accent"><a href="http://twitter.com/home?status=[PAGEURL]" target="_blank">T</a></li>
<li class="message_sharing_email greyback_primary_accent"><a href="mailto:?">E</a></li>
</ul>
</div>
<div class="message_controls">
<ul class="message_control_links">
<li id="e45178" class="message_control_listen greyback_primary_accent cms-editable"><a class="play" href="media/032716easter.mp3"><img id="e56c88" src="css/media/listen.jpg" alt="" width="79" height="24" /></a></li>
<li id="ed2201" class="message_control_download greyback_primary_accent cms-editable"><a class="dload" href="media/032716easter.mp3"><img id="ed3ef8" src="css/media/download.jpg" alt="" width="98" height="24" /></a><img id="e63a09" src="css/media/notes.jpg" alt="" width="81" height="24" /></li>
</ul>
</div>
</div>
<div class="audio_player" id="e82ca0"><audio controls="controls"></audio></div>
</div>
<!-- end media --></div>
<!-- message_archive_message --></div><!-- message_archive -->
		</div><!-- end c-8-->
            
                <div class="c-4 sidebar">
                    
                    <div class="widget widget-news-events">
                        
                        <h3 class="widget-title cms-editable" id="events-title">&nbsp;</h3>
                        <ul>
                            <li class="cms-repeat" id="events-repeat">
<h3 id="event-heading" class="title cms-editable"><a href="gameplan.php">&nbsp;</a></h3>
<div class="excerpt" id="event-content-div">
<p id="event-content" class="cms-editable">&nbsp;</p>
</div>
</li>
                            
                        </ul>
                        
                    </div><!-- end widget-news-events-->                       
                </div><!-- end sidebar -->
            </div><!-- end wrap -->
        </div><!-- end content -->
        
    <!-- Include Footer -->
    <div id="footer">
        <div class="wrap">
            <div class="footer-content">

              <div class="c-4">
                  <div class="widget widget-about">
                    
                        <h3 class="widget-title cms-editable" id="footer-title1"><a href="http://connectionpoint4u.com/contactpage.php"><span style="color: #00ff00;">CONTACT US</span></a></h3>
                        <div class="excerpt cms-editable" id="footer-text1">
<p><span style="font-size: medium;">If you have any questions about our church, or maybe you simply need prayer please click here.</span></p>
<p><span style="font-size: medium;">&nbsp;</span></p>
<p><span style="font-size: medium;">&nbsp;</span></p>
</div>    
                    </div><!-- end widget-about --> 
                </div>
                
                <div class="c-4">
              	     <div class="widget widget-about">
                 	 <h3 class="widget-title cms-editable" id="footer-title2"><strong><a href="location2014.php"><span style="color: #00ff00;">LOCATION</span></a></strong></h3>
                     
                        <div class="excerpt cms-editable" id="footer-text2">
<p><strong>Premier Parties LLC. 81 Knox Ct.<br /> Barbourville, KY 40906. <br /></strong></p>
<p><strong><span style="color: #00ff00;"><a title="Map of Barbourville, KY" href="https://mapsengine.google.com/map/edit?mid=zvFuqdkx4viw.kFFf35OTKBtA" target="_blank"><span style="color: #00ff00;">MAP</span></a></span>&nbsp;&nbsp;&nbsp;&nbsp; <span style="color: #00ff00;"><a title="Directions to Connection Point Church" href="https://maps.google.com/maps?daddr=Cr-1177Q,+Barbourville,+KY+40906.&amp;hl=en&amp;sll=37.208457,-82.710571&amp;sspn=4.125108,4.059448&amp;t=h&amp;mra=mdsmb&amp;disamb=1&amp;z=17" target="_blank"><span style="color: #00ff00;">DIRECTIONS</span></a></span><br /></strong></p>
</div>    
                     </div><!-- end widget-about -->  
                </div>
                
                <div class="c-4">
                 <div class="widget widget-about">
                 	 <h3 class="widget-title cms-editable" id="footer-title3"><span style="color: #00ff00;">SOCIAL MEDIA</span></h3>
                     
                       <div class="excerpt cms-editable" id="footer-text3">
<p><strong><a href="https://twitter.com/ConnectPoint4u" target="_blank"><img id="e1a4e2" src="https://lh3.ggpht.com/lSLM0xhCA1RZOwaQcjhlwmsvaIQYaP3c5qbDKCgLALhydrgExnaSKZdGa8S3YtRuVA=w300" alt="http://twitter.com" width="48" height="48" /></a>&nbsp; &nbsp;&nbsp;</strong><strong style="font-size: 12px; background-color: #202020;"><a style="font-size: 12px; color: #ffffff;" href="https://www.facebook.com/connectionpoint4u" target="_blank"><img id="e73973" style="margin-bottom: 2px;" src="https://en.facebookbrand.com/wp-content/uploads/2016/05/FB-fLogo-Blue-broadcast-2.png" alt="facebook.com" width="44" height="44" /></a>&nbsp; &nbsp;&nbsp;</strong><strong style="font-size: 12px;"><a href="https://www.instagram.com/connectionpoint4u" target="_blank"><img id="e2d2b5" src="/cms-assets/images/464444.igglyphfill.png" alt="instagram.com" width="45" height="45" /></a>&nbsp; &nbsp; &nbsp;&nbsp;</strong></p>
<p><strong><a title="YouTube Channel" href="https://www.youtube.com/channel/UCkQONmzujho4lbxIRxzWteQ/feed?view_as=public" target="_blank"><img id="ee2891" style="display: none !important;" title="YouTube Channel" src="/~connectp/cms-assets/images/980189.youtube.png" alt="YouTube Channel" width="48" height="48" /></a></strong></p>
<script type="text/javascript">// <![CDATA[
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-47042572-1', 'connectionpoint4u.com');
  ga('send', 'pageview');
// ]]></script></div>    
                     </div><!-- end widget-about -->  
                </div>
                </div>
                </div><!-- end wrap -->
                
                <div class="wrap">

                <br>
                <div class="c-6">
                      <a href="http://bridgeelement.com" target="_blank">Church Websites by Bridge Element</a>
		</div>
                  
        	</div><!-- end wrap -->
          
        </div><!-- end footer -->
        
           
    <!-- Include Google Tracker -->
    <!-- FOR THE CLIENT -->
<script type="text/javascript">
  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-xxxxxxx-x']);
  _gaq.push(['_trackPageview']);
  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();
</script>

<!-- FOR THE DASHBOARD -->
<script type="text/javascript">
  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-42406122-34']);
  _gaq.push(['_trackPageview']);
  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();
</script>

<script type="text/javascript">
  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-2565586-4']);
  _gaq.push(['_trackPageview']);
  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();
</script>     
	<script type="text/javascript" src="css/media/mediaelement-and-player.min.js"></script>
</body>
</html>
