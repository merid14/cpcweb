
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

  <title>Connection Point Church</title>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <meta name="description" content="Reaching un-churched and de-churched people." />
  <meta name="keywords" content="connection point church, barbourville, KY, connectionpoint4u, churches is 40906" />
  <meta name="Robots" content="index, follow" />
        
    <!-- Favicon -->
  <link href="favicon.ico" type="image/x-icon" rel="shortcut icon">
    
    <!-- Include CSS -->
    <!-- DNS Prefetch -->
	<link rel="dns-prefetch" href="//ajax.googleapis.com">
	<link rel="dns-prefetch" href="//fonts.googleapis.com">
	<link rel="dns-prefetch" href="//cdn.mybridgeelement.com">

<!-- Design CSS -->
	<link rel="stylesheet" type="text/css" media="screen" href="http://cdn.mybridgeelement.com/_cornerstone/main.css" />
	<link rel="stylesheet" type="text/css" media="screen" href="http://cdn.mybridgeelement.com/_cornerstone/media.css" />
	<link rel="stylesheet" type="text/css" media="screen" href="http://cdn.mybridgeelement.com/_cornerstone/media/mediaelementplayer.min.css" />
	<link rel="stylesheet" type="text/css" media="screen" href="css/style.css" />
	<link rel="stylesheet" type="text/css" media="screen" href="/css/style.css" />
	<link href='http://fonts.googleapis.com/css?family=PT+Sans+Narrow:700' rel='stylesheet' type='text/css'>
	<link href='http://fonts.googleapis.com/css?family=Reenie+Beanie' rel='stylesheet' type='text/css'>
    
<!-- Scripts -->
	<script src="//ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
	<script>window.jQuery || document.write('<script src="js/jquery-1.6.2.min.js"><\/script>')</script>
	<!-- CMS:REMOVE -->
	<script type="text/javascript" src="http://cdn.mybridgeelement.com/js/jCarouselLite.js"></script>
	<script type="text/javascript" src="http://cdn.mybridgeelement.com/js/jquery.innerfade.js"></script>
	<!-- CMS:END-REMOVE -->
	<script type="text/javascript" src="http://cdn.mybridgeelement.com/js/main_cornerstone.js"></script> 
	<script type="text/javascript" src="http://cdn.mybridgeelement.com/js/modernizr-2.0.6.min.js"></script> 
 
<!-- Disqus ID -->


<!-- Folder Links -->
<script type="text/javascript">
var folder = 'public_html';
</script>
<script type="text/javascript">
if(folder != 'public_html') {
$(function() {
   $('a:not([href*=":"])').each(function() {
       var href = $(this).attr('href');
       $(this).attr('href', '../' + href);  
   });
});
}
</script>

<!-- Image Links -->
<script type="text/javascript">
$(function() {
$('.tag .each(function() {
   $('img .each(function() {
       var href = $(this).attr('href');
       $(this).attr('href', '(dynRoot()' + href);  
   });
  }); 
});
</script>
</head>
<body class="home">  
      
      <!-- Include Logo and Menu -->
    <div id="topbar"></div>
<div id="header">
	
            <div class="wrap">
            
                <h1 class="logo">
                    <a href="index.php">
                        <img src="/cms-assets/zoom-cropped-images/464535_165_logo-image.png?rand=0.27698214851389014" class="cms-editable" id="logo-image" width="400" height="101"  alt="" />
                    </a>
                </h1>
                
                <h3 class="header-title cms-editable" id="header-title"><span style="color: #00ff00;"><strong><br />Getting Connected&hellip;<br />Changing Lives...<br />Building Community...<br />One Life At A Time!!!<br /></strong></span> <script type="text/javascript">// <![CDATA[
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-96551914-1', 'auto');
  ga('send', 'pageview');
// ]]></script></h3>
                <div class="cms-navigation" id="main-navigation">                        <ul class="dd-menu"> 
<li>
<a href="index.php" class="dd-submenu-title">HOME</a>
</li>
<li>
<a href="#" class="dd-submenu-title">NEW HERE</a>
<ul>

<li class="arrow"></li>
<li><a href="whattoexpect.php">Sunday Service</a></li>
<li><a href="staff.php">Leadership</a></li>
<li><a href="beliefs.php">Beliefs</a></li>
<li><a href="location2014.php">Location</a></li>
<li><a href="/kids.php">Kids</a></li>
<li><a href="/~connectp/smallgroups.php">Connect Groups</a></li>
<li><a href="vision.php">Vision and Values</a></li>
</ul>
</li>
<li>
<a href="#" class="dd-submenu-title">NEXT STEPS</a>
<ul>

<li class="arrow"></li>
<li><a href="smallgroups.php">Connect Groups</a></li>
<li><a href="salvation.php">Salvation</a></li>
<li><a href="baptism.php">Baptism</a></li>
<li><a href="/~connectp/serving.php">Serving</a></li>
</ul>
</li>
<li>
<a href="media.php" class="dd-submenu-title">MEDIA</a>
</li>
<li>
<a href="contactpage.php" class="dd-submenu-title">CONTACT US</a>
</li>
<li>
<a href="http://www.mybridgeelementgiving.com/dl/?uid=connpob296" class="dd-submenu-title">GIVE</a>
</li>
<li>
<a href="/~connectp/takesonetonoone.php" class="dd-submenu-title">LISTEN NOW!</a>
</li>
</ul>

                    </div><!-- end main-navigation-->                
                

            </div><!-- end wrap -->
</div><!-- end header -->        
        <div id="content" class="home">
        
          <div id="slider">
            <div class="wrap">
                
                
                <div class="mask"></div>
                <div id="big-slider">
                    
                    
                    <ul id="slideshow">
                        <li class="cms-repeat" id="banner-rotator"><a id="e8072d" class="cms-editable" href="http://connectionpoint4u.com/~connectp/head.php">&nbsp;</a><img id="e8c4cd" class="cms-editable" src="/cms-assets/zoom-cropped-images/464535_174_e8c4cd.jpg?rand=0.07096996162473812" alt="" width="950" height="270" /></li>
                        
                    </ul>
                   
                </div>
                
                <div class="c-12">

              
                <ul class="portfolio-menu">
                  <li class="c-3 four-column cms-repeat" id="index-repeat">
<h3 id="index-title" class="title cms-editable"><a title="Sunday Service" href="http://connectionpoint4u.com/whattoexpect.php"><span style="color: #00ff00;">SUNDAY SERVICE</span></a></h3>
<div class="excerpt">
<p id="index-text" class="cms-editable">Starting Easter Sunday 4/16/2017 we will be going to two services @ 9:15 or 11:04 am<br />What you can expect during our Sunday Morning Worship Experience!</p>
</div>
</li><li id="ea0f2c" class="c-3 four-column cms-repeat cms-previous-repeat-item-id-index-repeat">
<h3 id="e3cfff" class="title cms-editable"><a href="http://connectionpoint4u.com/smallgroups.php"><span style="color: #00ff00;"><strong><span style="color: #00ff00;">CONNECT GROUPS</span></strong></span></a></h3>
<div class="excerpt">
<p id="e34737" class="cms-editable">Learn more about, or sign up for one of our Connect Groups that meet in homes during different nights of the week.</p>
</div>
</li><li id="e11d69" class="c-3 four-column cms-repeat cms-previous-repeat-item-id-ea0f2c">
<h3 id="ed517" class="title cms-editable"><span style="color: #00ff00;"><strong><a href="http://www.mybridgeelementgiving.com/dl/?uid=connpob296"><span style="color: #00ff00;">GIVE</span></a></strong></span></h3>
<div class="excerpt">
<p id="eda093" class="cms-editable">Would you consider supporting all that God is doing through Connection Point Church?</p>
</div>
</li><li id="e9c537" class="c-3 four-column cms-repeat cms-previous-repeat-item-id-e11d69">
<h3 id="e34185" class="title cms-editable"><span style="color: #00ff00;"><a href="http://connectionpoint4u.com/media.php"><span style="color: #00ff00;">MEDIA</span></a></span></h3>
<div class="excerpt">
<p id="ea335b" class="cms-editable">Couldn't make it, or do you simply want to know what kind of stuff the preacher is shoot'n off during a worship service come have a listen to the sermons from here at CONNECTION POINT!</p>
</div>
</li>
                    
                    
                    </ul></div>
                   
      </div><!-- end wrap -->
            </div><!-- end slider -->
              
        </div><!-- end content -->
        
        <!-- Include Footer -->
    <div id="footer">
        <div class="wrap">
            <div class="footer-content">

              <div class="c-4">
                  <div class="widget widget-about">
                    
                        <h3 class="widget-title cms-editable" id="footer-title1"><a href="http://connectionpoint4u.com/contactpage.php"><span style="color: #00ff00;">CONTACT US</span></a></h3>
                        <div class="excerpt cms-editable" id="footer-text1">
<p><span style="font-size: medium;">If you have any questions about our church, or maybe you simply need prayer please click here.</span></p>
<p><span style="font-size: medium;">&nbsp;</span></p>
<p><span style="font-size: medium;">&nbsp;</span></p>
</div>    
                    </div><!-- end widget-about --> 
                </div>
                
                <div class="c-4">
              	     <div class="widget widget-about">
                 	 <h3 class="widget-title cms-editable" id="footer-title2"><strong><a href="location2014.php"><span style="color: #00ff00;">LOCATION</span></a></strong></h3>
                     
                        <div class="excerpt cms-editable" id="footer-text2">
<p><strong>Premier Parties LLC. 81 Knox Ct.<br /> Barbourville, KY 40906. <br /></strong></p>
<p><strong><span style="color: #00ff00;"><a title="Map of Barbourville, KY" href="https://mapsengine.google.com/map/edit?mid=zvFuqdkx4viw.kFFf35OTKBtA" target="_blank"><span style="color: #00ff00;">MAP</span></a></span>&nbsp;&nbsp;&nbsp;&nbsp; <span style="color: #00ff00;"><a title="Directions to Connection Point Church" href="https://maps.google.com/maps?daddr=Cr-1177Q,+Barbourville,+KY+40906.&amp;hl=en&amp;sll=37.208457,-82.710571&amp;sspn=4.125108,4.059448&amp;t=h&amp;mra=mdsmb&amp;disamb=1&amp;z=17" target="_blank"><span style="color: #00ff00;">DIRECTIONS</span></a></span><br /></strong></p>
</div>    
                     </div><!-- end widget-about -->  
                </div>
                
                <div class="c-4">
                 <div class="widget widget-about">
                 	 <h3 class="widget-title cms-editable" id="footer-title3"><span style="color: #00ff00;">SOCIAL MEDIA</span></h3>
                     
                       <div class="excerpt cms-editable" id="footer-text3">
<p><strong><a href="https://twitter.com/ConnectPoint4u" target="_blank"><img id="e1a4e2" src="https://lh3.ggpht.com/lSLM0xhCA1RZOwaQcjhlwmsvaIQYaP3c5qbDKCgLALhydrgExnaSKZdGa8S3YtRuVA=w300" alt="http://twitter.com" width="48" height="48" /></a>&nbsp; &nbsp;&nbsp;</strong><strong style="font-size: 12px; background-color: #202020;"><a style="font-size: 12px; color: #ffffff;" href="https://www.facebook.com/connectionpoint4u" target="_blank"><img id="e73973" style="margin-bottom: 2px;" src="https://en.facebookbrand.com/wp-content/uploads/2016/05/FB-fLogo-Blue-broadcast-2.png" alt="facebook.com" width="44" height="44" /></a>&nbsp; &nbsp;&nbsp;</strong><strong style="font-size: 12px;"><a href="https://www.instagram.com/connectionpoint4u" target="_blank"><img id="e2d2b5" src="/cms-assets/images/464444.igglyphfill.png" alt="instagram.com" width="45" height="45" /></a>&nbsp; &nbsp; &nbsp;&nbsp;</strong></p>
<p><strong><a title="YouTube Channel" href="https://www.youtube.com/channel/UCkQONmzujho4lbxIRxzWteQ/feed?view_as=public" target="_blank"><img id="ee2891" style="display: none !important;" title="YouTube Channel" src="/~connectp/cms-assets/images/980189.youtube.png" alt="YouTube Channel" width="48" height="48" /></a></strong></p>
<script type="text/javascript">// <![CDATA[
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-47042572-1', 'connectionpoint4u.com');
  ga('send', 'pageview');
// ]]></script>
</div>    
                     </div><!-- end widget-about -->  
                </div>
                </div>
                </div><!-- end wrap -->
                
                <div class="wrap">

                <br>
                <div class="c-6">
                      <a href="http://bridgeelement.com" target="_blank">Church Websites by Bridge Element</a>
		</div>
                  
        	</div><!-- end wrap -->
          
        </div><!-- end footer -->
        
           
     <!-- Include Google Tracker -->
    <!-- FOR THE CLIENT -->
<script type="text/javascript">
  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-xxxxxxx-x']);
  _gaq.push(['_trackPageview']);
  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();
</script>

<!-- FOR THE DASHBOARD -->
<script type="text/javascript">
  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-42406122-34']);
  _gaq.push(['_trackPageview']);
  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();
</script>

<script type="text/javascript">
  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-2565586-4']);
  _gaq.push(['_trackPageview']);
  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();
</script>

</body>
</html>
