 

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

  <title>WE ARE</title>
   <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <meta name="description" content="Knowing who WE ARE as the church, the body of Christ, empowers us to live out God's purpose for our lives TOGETHER. Our strength comes from unity." />
  <meta name="keywords" content="we are, sermon, series, August series, " />
  <meta name="Robots" content="index, follow" />
        
    <!-- Favicon -->
  <link href="favicon.ico" type="image/x-icon" rel="shortcut icon">
    
    <!-- Include CSS -->
    <!-- DNS Prefetch -->
	<link rel="dns-prefetch" href="//ajax.googleapis.com">
	<link rel="dns-prefetch" href="//fonts.googleapis.com">
	<link rel="dns-prefetch" href="//cdn.mybridgeelement.com">

<!-- Design CSS -->
	<link rel="stylesheet" type="text/css" media="screen" href="http://cdn.mybridgeelement.com/_cornerstone/main.css" />
	<link rel="stylesheet" type="text/css" media="screen" href="http://cdn.mybridgeelement.com/_cornerstone/media.css" />
	<link rel="stylesheet" type="text/css" media="screen" href="http://cdn.mybridgeelement.com/_cornerstone/media/mediaelementplayer.min.css" />
	<link rel="stylesheet" type="text/css" media="screen" href="css/style.css" />
	<link rel="stylesheet" type="text/css" media="screen" href="/css/style.css" />
	<link href='http://fonts.googleapis.com/css?family=PT+Sans+Narrow:700' rel='stylesheet' type='text/css'>
	<link href='http://fonts.googleapis.com/css?family=Reenie+Beanie' rel='stylesheet' type='text/css'>
    
<!-- Scripts -->
	<script src="//ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
	<script>window.jQuery || document.write('<script src="js/jquery-1.6.2.min.js"><\/script>')</script>
	<!-- CMS:REMOVE -->
	<script type="text/javascript" src="http://cdn.mybridgeelement.com/js/jCarouselLite.js"></script>
	<script type="text/javascript" src="http://cdn.mybridgeelement.com/js/jquery.innerfade.js"></script>
	<!-- CMS:END-REMOVE -->
	<script type="text/javascript" src="http://cdn.mybridgeelement.com/js/main_cornerstone.js"></script> 
	<script type="text/javascript" src="http://cdn.mybridgeelement.com/js/modernizr-2.0.6.min.js"></script> 
 
<!-- Disqus ID -->


<!-- Folder Links -->
<script type="text/javascript">
var folder = 'public_html';
</script>
<script type="text/javascript">
if(folder != 'public_html') {
$(function() {
   $('a:not([href*=":"])').each(function() {
       var href = $(this).attr('href');
       $(this).attr('href', '../' + href);  
   });
});
}
</script>

<!-- Image Links -->
<script type="text/javascript">
$(function() {
$('.tag .each(function() {
   $('img .each(function() {
       var href = $(this).attr('href');
       $(this).attr('href', '(dynRoot()' + href);  
   });
  }); 
});
</script>  

<style type="text/css">
  
    #content .wrap {
  width: 1000px;
  }
    </style>
    
</head>

<body class="home">  
      
    <!-- Include Logo and Menu -->
    <div id="topbar"></div>
<div id="header">
	
            <div class="wrap">
            
                <h1 class="logo">
                    <a href="index.php">
                        <img src="/cms-assets/zoom-cropped-images/464535_165_logo-image.png?rand=0.27698214851389014" class="cms-editable" id="logo-image" width="400" height="101"  alt="" />
                    </a>
                </h1>
                
                <h3 class="header-title cms-editable" id="header-title"><span style="color: #00ff00;"><strong><br />Getting Connected&hellip;<br />Changing Lives...<br />Building Community...<br />One Life At A Time!!!<br /></strong></span> <script type="text/javascript">// <![CDATA[
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-96551914-1', 'auto');
  ga('send', 'pageview');
// ]]></script></h3>
                <div class="cms-navigation" id="main-navigation">                        <ul class="dd-menu"> 
<li>
<a href="index.php" class="dd-submenu-title">HOME</a>
</li>
<li>
<a href="#" class="dd-submenu-title">NEW HERE</a>
<ul>

<li class="arrow"></li>
<li><a href="whattoexpect.php">Sunday Service</a></li>
<li><a href="staff.php">Leadership</a></li>
<li><a href="beliefs.php">Beliefs</a></li>
<li><a href="location2014.php">Location</a></li>
<li><a href="/kids.php">Kids</a></li>
<li><a href="/~connectp/smallgroups.php">Connect Groups</a></li>
<li><a href="vision.php">Vision and Values</a></li>
</ul>
</li>
<li>
<a href="#" class="dd-submenu-title">NEXT STEPS</a>
<ul>

<li class="arrow"></li>
<li><a href="smallgroups.php">Connect Groups</a></li>
<li><a href="salvation.php">Salvation</a></li>
<li><a href="baptism.php">Baptism</a></li>
<li><a href="/~connectp/serving.php">Serving</a></li>
</ul>
</li>
<li>
<a href="media.php" class="dd-submenu-title">MEDIA</a>
</li>
<li>
<a href="contactpage.php" class="dd-submenu-title">CONTACT US</a>
</li>
<li>
<a href="http://www.mybridgeelementgiving.com/dl/?uid=connpob296" class="dd-submenu-title">GIVE</a>
</li>
<li>
<a href="/~connectp/takesonetonoone.php" class="dd-submenu-title">LISTEN NOW!</a>
</li>
</ul>

                    </div><!-- end main-navigation-->                
                

            </div><!-- end wrap -->
</div><!-- end header -->  
        
        
        
        <div id="content">
        
          <div class="wrap">
              <div class="c-8 divider">
              
<script type="text/javascript">
  
  var currentPlayer;
  $(function(){
  
  $('.play').click(function() {
    $('.player').hide();
    player_div = $(this).attr('rel');
    container = $('#'+player_div);
    container.fadeIn();
    player =  $('#'+player_div+' audio');
    player.attr('src',$(this).attr('href'));
    
    try {
      player.mediaelementplayer({
        audioWidth:container.width(),
        success:function(mediaElement,domObject) {
          mediaElement.play();
          currentPlayer = mediaElement;
        }
      });
      
    } catch(e) {
      
    }
    return false;
  });
  $('.dload').each(function () { var href = $(this).attr('href'); $(this).attr('href', 'download.php?f=' + href); });
  $('.play').each(function(){
      $(this).attr("rel",$(this).closest('.message_buttons').next('.audio_player').attr('id'));
  });

  });
  $(function() {
    var links = $('.message_sharing a'),
        matchExp = /\[PAGEURL\]/,
        currentURL = location.href;

    links.each(function() {
        var currentHREF = $(this).attr('href');
        if (currentHREF.match(matchExp)) {
            $(this).attr('href',currentHREF.replace(matchExp,currentURL));
        }
    });

});
</script>

<div class="message_archive">
      <div class="message_archive_message">
      <div class="message_series_image" id="series-image"><img id="e9135b" class="cms-editable" src="/cms-assets/zoom-cropped-images/670389_1_e9135b.png?rand=0.6883360940591059" alt="" width="595" height="280" /></div>
      <div class="message_details">
        <div><h1 class="message_title cms-editable" id="title">WE ARE</h1></div>
        <div class="series_description cms-editable-text" id="Series_desc">Does the world struggle with identity? Yes...yes it does! Do we as individuals struggle with identity and who "we are"? Yes...yes we do. If that is true then it may be true that the church is also struggling with knowing who WE ARE! We get that figured out...look out world...cuz the GOOD NEWS is coming!!</div>
  

      </div><!-- end message_details-->
      </div><!-- message_archive_message -->
    </div><!-- message_archive -->
    
    
    
              


    <div class="message_archive cms-repeat" id="message-repeat">
<div class="message_archive_message">
<div class="media">
<h4 id="info" class="message_info cms-editable"><strong>WE ARE...INVITERS, Connected people Connect with people.&nbsp;Week One</strong><br />August 7, 2016, Pastor Jeremiah</h4>
<div class="message_description cms-editable" id="desc">
<p>Our entire life story can be told through the lense of invitations. Truth is that we have no idea what hangs in the balance of inviting someone to connect to what we have connect with; WE ARE INVITERS!</p>
</div>
<div class="message_buttons">
<div class="message_sharing">
<ul class="message_sharing_links">
<li class="greyback_primary message_sharing_share">Share:</li>
<li class="message_sharing_facebook greyback_primary_accent"><a href="http://www.facebook.com/sharer.php?u=[PAGEURL]" target="_blank">F</a></li>
<li class="message_sharing_twitter greyback_primary_accent"><a href="http://twitter.com/home?status=[PAGEURL]" target="_blank">T</a></li>
<li class="message_sharing_email greyback_primary_accent"><a href="mailto:?">E</a></li>
</ul>
</div>
<div class="message_controls">
<ul class="message_control_links">
<li id="listen" class="message_control_listen greyback_primary_accent cms-editable"><a class="play" href="media/weare080716.mp3"><img id="e559e4" src="css/media/listen.jpg" alt="" width="79" height="24" /></a></li>
<li id="download" class="message_control_download greyback_primary_accent cms-editable"><a class="dload"><img id="e2cda8" src="css/media/download.jpg" alt="" width="98" height="24" /></a><img id="ed38f" src="css/media/notes.jpg" alt="" width="81" height="24" /><img id="ea2cc9" src="css/media/transcript.jpg" alt="" width="107" height="24" /></li>
</ul>
</div>
</div>
<div class="audio_player" id="play1243"><audio controls="controls"></audio></div>
</div>
<!-- end media --></div>
<!-- message_archive_message --></div><div class="message_archive cms-repeat cms-previous-repeat-item-id-message-repeat" id="e9765e">
<div class="message_archive_message">
<div class="media">
<h4 id="eeaf06" class="message_info cms-editable"><strong>WE ARE...TRANSFORMING, Transforming people Change.&nbsp;Week 2</strong><br />August 14, 2016, Pastor Jeremiah</h4>
<div class="message_description cms-editable" id="e6db5b">
<p>Transformation of life is not a project or a program...it is a process. It is a lifestyle. Listen in as our pastor passoinately shares 7 things we can do that result in Life Change!</p>
</div>
<div class="message_buttons">
<div class="message_sharing">
<ul class="message_sharing_links">
<li class="greyback_primary message_sharing_share">Share:</li>
<li class="message_sharing_facebook greyback_primary_accent"><a href="http://www.facebook.com/sharer.php?u=[PAGEURL]" target="_blank">F</a></li>
<li class="message_sharing_twitter greyback_primary_accent"><a href="http://twitter.com/home?status=[PAGEURL]" target="_blank">T</a></li>
<li class="message_sharing_email greyback_primary_accent"><a href="mailto:?">E</a></li>
</ul>
</div>
<div class="message_controls">
<ul class="message_control_links">
<li id="ee45e9" class="message_control_listen greyback_primary_accent cms-editable"><a class="play" href="media/weare081416.mp3"><img id="e9b74d" src="css/media/listen.jpg" alt="" width="79" height="24" /></a></li>
<li id="ef1014" class="message_control_download greyback_primary_accent cms-editable"><a class="dload"><img id="e7dc3d" src="css/media/download.jpg" alt="" width="98" height="24" /></a><img id="eb2ccb" src="css/media/notes.jpg" alt="" width="81" height="24" /><img id="ec962b" src="css/media/transcript.jpg" alt="" width="107" height="24" /></li>
</ul>
</div>
</div>
<div class="audio_player" id="ebe9aa"><audio controls="controls"></audio></div>
</div>
<!-- end media --></div>
<!-- message_archive_message --></div><div class="message_archive cms-repeat cms-previous-repeat-item-id-e9765e" id="e6284a">
<div class="message_archive_message">
<div class="media">
<h4 id="e99c0f" class="message_info cms-editable"><strong>WE ARE...ONE, Building Community IS&nbsp;Doing Life Together.&nbsp;Week 3</strong><br />August 21, 2016, Pastor Jeremiah</h4>
<div class="message_description cms-editable" id="e13873">
<p>Listen in as Pastor Jeremiah gives a History lesson of the early church and how they saw so much radical growth. When applying this to how we do church you find out really quick how important it is that in order to experience UNITY in the church you must first BUILD COMMUNITY!</p>
</div>
<div class="message_buttons">
<div class="message_sharing">
<ul class="message_sharing_links">
<li class="greyback_primary message_sharing_share">Share:</li>
<li class="message_sharing_facebook greyback_primary_accent"><a href="http://www.facebook.com/sharer.php?u=[PAGEURL]" target="_blank">F</a></li>
<li class="message_sharing_twitter greyback_primary_accent"><a href="http://twitter.com/home?status=[PAGEURL]" target="_blank">T</a></li>
<li class="message_sharing_email greyback_primary_accent"><a href="mailto:?">E</a></li>
</ul>
</div>
<div class="message_controls">
<ul class="message_control_links">
<li id="e37af4" class="message_control_listen greyback_primary_accent cms-editable"><a class="play" href="media/weare082116.mp3"><img id="e4b43f" src="css/media/listen.jpg" alt="" width="79" height="24" /></a></li>
<li id="e9301c" class="message_control_download greyback_primary_accent cms-editable"><a class="dload"><img id="e73761" src="css/media/download.jpg" alt="" width="98" height="24" /></a><img id="ec31a" src="css/media/notes.jpg" alt="" width="81" height="24" /><img id="e64f9f" src="css/media/transcript.jpg" alt="" width="107" height="24" /></li>
</ul>
</div>
</div>
<div class="audio_player" id="ec1b46"><audio controls="controls"></audio></div>
</div>
<!-- end media --></div>
<!-- message_archive_message --></div><div class="message_archive cms-repeat cms-previous-repeat-item-id-e6284a" id="e1ac28">
<div class="message_archive_message">
<div class="media">
<h4 id="eb1137" class="message_info cms-editable"><strong>WE ARE: ALL IN, We cannot out-give God.&nbsp;Week 4<br /></strong>August 28, 2016, Pastor Jeremiah</h4>
<div class="message_description cms-editable" id="ebf505">
<p>Generosity is a key ingredient to experiencing life change, but the truth is that we can never OUT-GIVE GOD!!</p>
</div>
<div class="message_buttons">
<div class="message_sharing">
<ul class="message_sharing_links">
<li class="greyback_primary message_sharing_share">Share:</li>
<li class="message_sharing_facebook greyback_primary_accent"><a href="http://www.facebook.com/sharer.php?u=[PAGEURL]" target="_blank">F</a></li>
<li class="message_sharing_twitter greyback_primary_accent"><a href="http://twitter.com/home?status=[PAGEURL]" target="_blank">T</a></li>
<li class="message_sharing_email greyback_primary_accent"><a href="mailto:?">E</a></li>
</ul>
</div>
<div class="message_controls">
<ul class="message_control_links">
<li id="e7bc4a" class="message_control_listen greyback_primary_accent cms-editable"><a class="play" href="media/weare082816.mp3"><img id="e648fc" src="css/media/listen.jpg" alt="" width="79" height="24" /></a></li>
<li id="e7996f" class="message_control_download greyback_primary_accent cms-editable"><a class="dload"><img id="ec6203" src="css/media/download.jpg" alt="" width="98" height="24" /></a><img id="ec9da2" src="css/media/notes.jpg" alt="" width="81" height="24" /><img id="ee0c29" src="css/media/transcript.jpg" alt="" width="107" height="24" /></li>
</ul>
</div>
</div>
<div class="audio_player" id="e2cc83"><audio controls="controls"></audio></div>
</div>
<!-- end media --></div>
<!-- message_archive_message --></div><div class="message_archive cms-repeat cms-previous-repeat-item-id-e1ac28" id="ed4163">
<div class="message_archive_message">
<div class="media">
<h4 id="e50e5a" class="message_info cms-editable"><strong>WE ARE: SERVANTEERS, Changed people Serve people.&nbsp;Week 5<br /></strong>September 4, 2016, Pastor Jeremiah</h4>
<div class="message_description cms-editable" id="e6fffa">
<p>Changed people SERVE people in order that served people CHANGE!</p>
</div>
<div class="message_buttons">
<div class="message_sharing">
<ul class="message_sharing_links">
<li class="greyback_primary message_sharing_share">Share:</li>
<li class="message_sharing_facebook greyback_primary_accent"><a href="http://www.facebook.com/sharer.php?u=[PAGEURL]" target="_blank">F</a></li>
<li class="message_sharing_twitter greyback_primary_accent"><a href="http://twitter.com/home?status=[PAGEURL]" target="_blank">T</a></li>
<li class="message_sharing_email greyback_primary_accent"><a href="mailto:?">E</a></li>
</ul>
</div>
<div class="message_controls">
<ul class="message_control_links">
<li id="eec8b8" class="message_control_listen greyback_primary_accent cms-editable"><a class="play" href="media/weare090416.mp3"><img id="ecfd5" src="css/media/listen.jpg" alt="" width="79" height="24" /></a></li>
<li id="ed33a6" class="message_control_download greyback_primary_accent cms-editable"><a class="dload"><img id="e422c0" src="css/media/download.jpg" alt="" width="98" height="24" /></a><img id="e3fa2" src="css/media/notes.jpg" alt="" width="81" height="24" /><img id="e4dc51" src="css/media/transcript.jpg" alt="" width="107" height="24" /></li>
</ul>
</div>
</div>
<div class="audio_player" id="eda1ba"><audio controls="controls"></audio></div>
</div>
<!-- end media --></div>
<!-- message_archive_message --></div><!-- message_archive -->
    </div><!-- end c-8-->
            
                <div class="c-4 sidebar">
              
              
              
            </div><!-- end wrap -->
        </div><!-- end content -->
        
    <!-- Include Footer -->
    <div id="footer">
        <div class="wrap">
            <div class="footer-content">

              <div class="c-4">
                  <div class="widget widget-about">
                    
                        <h3 class="widget-title cms-editable" id="footer-title1"><a href="http://connectionpoint4u.com/contactpage.php"><span style="color: #00ff00;">CONTACT US</span></a></h3>
                        <div class="excerpt cms-editable" id="footer-text1">
<p><span style="font-size: medium;">If you have any questions about our church, or maybe you simply need prayer please click here.</span></p>
<p><span style="font-size: medium;">&nbsp;</span></p>
<p><span style="font-size: medium;">&nbsp;</span></p>
</div>    
                    </div><!-- end widget-about --> 
                </div>
                
                <div class="c-4">
              	     <div class="widget widget-about">
                 	 <h3 class="widget-title cms-editable" id="footer-title2"><strong><a href="location2014.php"><span style="color: #00ff00;">LOCATION</span></a></strong></h3>
                     
                        <div class="excerpt cms-editable" id="footer-text2">
<p><strong>Premier Parties LLC. 81 Knox Ct.<br /> Barbourville, KY 40906. <br /></strong></p>
<p><strong><span style="color: #00ff00;"><a title="Map of Barbourville, KY" href="https://mapsengine.google.com/map/edit?mid=zvFuqdkx4viw.kFFf35OTKBtA" target="_blank"><span style="color: #00ff00;">MAP</span></a></span>&nbsp;&nbsp;&nbsp;&nbsp; <span style="color: #00ff00;"><a title="Directions to Connection Point Church" href="https://maps.google.com/maps?daddr=Cr-1177Q,+Barbourville,+KY+40906.&amp;hl=en&amp;sll=37.208457,-82.710571&amp;sspn=4.125108,4.059448&amp;t=h&amp;mra=mdsmb&amp;disamb=1&amp;z=17" target="_blank"><span style="color: #00ff00;">DIRECTIONS</span></a></span><br /></strong></p>
</div>    
                     </div><!-- end widget-about -->  
                </div>
                
                <div class="c-4">
                 <div class="widget widget-about">
                 	 <h3 class="widget-title cms-editable" id="footer-title3"><span style="color: #00ff00;">SOCIAL MEDIA</span></h3>
                     
                       <div class="excerpt cms-editable" id="footer-text3">
<p><strong><a href="https://twitter.com/ConnectPoint4u" target="_blank"><img id="e1a4e2" src="https://lh3.ggpht.com/lSLM0xhCA1RZOwaQcjhlwmsvaIQYaP3c5qbDKCgLALhydrgExnaSKZdGa8S3YtRuVA=w300" alt="http://twitter.com" width="48" height="48" /></a>&nbsp; &nbsp;&nbsp;</strong><strong style="font-size: 12px; background-color: #202020;"><a style="font-size: 12px; color: #ffffff;" href="https://www.facebook.com/connectionpoint4u" target="_blank"><img id="e73973" style="margin-bottom: 2px;" src="https://en.facebookbrand.com/wp-content/uploads/2016/05/FB-fLogo-Blue-broadcast-2.png" alt="facebook.com" width="44" height="44" /></a>&nbsp; &nbsp;&nbsp;</strong><strong style="font-size: 12px;"><a href="https://www.instagram.com/connectionpoint4u" target="_blank"><img id="e2d2b5" src="/cms-assets/images/464444.igglyphfill.png" alt="instagram.com" width="45" height="45" /></a>&nbsp; &nbsp; &nbsp;&nbsp;</strong></p>
<p><strong><a title="YouTube Channel" href="https://www.youtube.com/channel/UCkQONmzujho4lbxIRxzWteQ/feed?view_as=public" target="_blank"><img id="ee2891" style="display: none !important;" title="YouTube Channel" src="/~connectp/cms-assets/images/980189.youtube.png" alt="YouTube Channel" width="48" height="48" /></a></strong></p>
<script type="text/javascript">// <![CDATA[
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-47042572-1', 'connectionpoint4u.com');
  ga('send', 'pageview');
// ]]></script>
</div>    
                     </div><!-- end widget-about -->  
                </div>
                </div>
                </div><!-- end wrap -->
                
                <div class="wrap">

                <br>
                <div class="c-6">
                      <a href="http://bridgeelement.com" target="_blank">Church Websites by Bridge Element</a>
		</div>
                  
        	</div><!-- end wrap -->
          
        </div><!-- end footer -->
        
         
    
    <!-- Include Google Tracker -->
    <!-- FOR THE CLIENT -->
<script type="text/javascript">
  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-xxxxxxx-x']);
  _gaq.push(['_trackPageview']);
  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();
</script>

<!-- FOR THE DASHBOARD -->
<script type="text/javascript">
  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-42406122-34']);
  _gaq.push(['_trackPageview']);
  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();
</script>

<script type="text/javascript">
  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-2565586-4']);
  _gaq.push(['_trackPageview']);
  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();
</script>  

</body>
</html>
