 

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

  <title>ENGAGE</title>
   <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <meta name="description" content="Everything hinges on relationships, but we must first engage." />
  <meta name="keywords" content="relationships, engage, sermon, series, february series, " />
  <meta name="Robots" content="index, follow" />
        
    <!-- Favicon -->
  <link href="favicon.ico" type="image/x-icon" rel="shortcut icon">
    
    <!-- Include CSS -->
    <!-- DNS Prefetch -->
	<link rel="dns-prefetch" href="//ajax.googleapis.com">
	<link rel="dns-prefetch" href="//fonts.googleapis.com">
	<link rel="dns-prefetch" href="//cdn.mybridgeelement.com">

<!-- Design CSS -->
	<link rel="stylesheet" type="text/css" media="screen" href="http://cdn.mybridgeelement.com/_cornerstone/main.css" />
	<link rel="stylesheet" type="text/css" media="screen" href="http://cdn.mybridgeelement.com/_cornerstone/media.css" />
	<link rel="stylesheet" type="text/css" media="screen" href="http://cdn.mybridgeelement.com/_cornerstone/media/mediaelementplayer.min.css" />
	<link rel="stylesheet" type="text/css" media="screen" href="css/style.css" />
	<link rel="stylesheet" type="text/css" media="screen" href="/css/style.css" />
	<link href='http://fonts.googleapis.com/css?family=PT+Sans+Narrow:700' rel='stylesheet' type='text/css'>
	<link href='http://fonts.googleapis.com/css?family=Reenie+Beanie' rel='stylesheet' type='text/css'>
    
<!-- Scripts -->
	<script src="//ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
	<script>window.jQuery || document.write('<script src="js/jquery-1.6.2.min.js"><\/script>')</script>
	<!-- CMS:REMOVE -->
	<script type="text/javascript" src="http://cdn.mybridgeelement.com/js/jCarouselLite.js"></script>
	<script type="text/javascript" src="http://cdn.mybridgeelement.com/js/jquery.innerfade.js"></script>
	<!-- CMS:END-REMOVE -->
	<script type="text/javascript" src="http://cdn.mybridgeelement.com/js/main_cornerstone.js"></script> 
	<script type="text/javascript" src="http://cdn.mybridgeelement.com/js/modernizr-2.0.6.min.js"></script> 
 
<!-- Disqus ID -->


<!-- Folder Links -->
<script type="text/javascript">
var folder = 'public_html';
</script>
<script type="text/javascript">
if(folder != 'public_html') {
$(function() {
   $('a:not([href*=":"])').each(function() {
       var href = $(this).attr('href');
       $(this).attr('href', '../' + href);  
   });
});
}
</script>

<!-- Image Links -->
<script type="text/javascript">
$(function() {
$('.tag .each(function() {
   $('img .each(function() {
       var href = $(this).attr('href');
       $(this).attr('href', '(dynRoot()' + href);  
   });
  }); 
});
</script>  

<style type="text/css">
  
    #content .wrap {
  width: 1000px;
  }
    </style>
    
</head>

<body class="home">  
      
    <!-- Include Logo and Menu -->
    <div id="topbar"></div>
<div id="header">
	
            <div class="wrap">
            
                <h1 class="logo">
                    <a href="index.php">
                        <img src="/cms-assets/zoom-cropped-images/464535_165_logo-image.png?rand=0.27698214851389014" class="cms-editable" id="logo-image" width="400" height="101"  alt="" />
                    </a>
                </h1>
                
                <h3 class="header-title cms-editable" id="header-title"><span style="color: #00ff00;"><strong><br />Getting Connected&hellip;<br />Changing Lives...<br />Building Community...<br />One Life At A Time!!!<br /></strong></span> <script type="text/javascript">// <![CDATA[
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-96551914-1', 'auto');
  ga('send', 'pageview');
// ]]></script></h3>
                <div class="cms-navigation" id="main-navigation">                        <ul class="dd-menu"> 
<li>
<a href="index.php" class="dd-submenu-title">HOME</a>
</li>
<li>
<a href="#" class="dd-submenu-title">NEW HERE</a>
<ul>

<li class="arrow"></li>
<li><a href="whattoexpect.php">Sunday Service</a></li>
<li><a href="staff.php">Leadership</a></li>
<li><a href="beliefs.php">Beliefs</a></li>
<li><a href="location2014.php">Location</a></li>
<li><a href="/kids.php">Kids</a></li>
<li><a href="/~connectp/smallgroups.php">Connect Groups</a></li>
<li><a href="vision.php">Vision and Values</a></li>
</ul>
</li>
<li>
<a href="#" class="dd-submenu-title">NEXT STEPS</a>
<ul>

<li class="arrow"></li>
<li><a href="smallgroups.php">Connect Groups</a></li>
<li><a href="salvation.php">Salvation</a></li>
<li><a href="baptism.php">Baptism</a></li>
<li><a href="/~connectp/serving.php">Serving</a></li>
</ul>
</li>
<li>
<a href="media.php" class="dd-submenu-title">MEDIA</a>
</li>
<li>
<a href="contactpage.php" class="dd-submenu-title">CONTACT US</a>
</li>
<li>
<a href="http://www.mybridgeelementgiving.com/dl/?uid=connpob296" class="dd-submenu-title">GIVE</a>
</li>
<li>
<a href="/~connectp/takesonetonoone.php" class="dd-submenu-title">LISTEN NOW!</a>
</li>
</ul>

                    </div><!-- end main-navigation-->                
                

            </div><!-- end wrap -->
</div><!-- end header -->  
        
        
        
        <div id="content">
        
          <div class="wrap">
              <div class="c-8 divider">
              
<script type="text/javascript">
  
  var currentPlayer;
  $(function(){
  
  $('.play').click(function() {
    $('.player').hide();
    player_div = $(this).attr('rel');
    container = $('#'+player_div);
    container.fadeIn();
    player =  $('#'+player_div+' audio');
    player.attr('src',$(this).attr('href'));
    
    try {
      player.mediaelementplayer({
        audioWidth:container.width(),
        success:function(mediaElement,domObject) {
          mediaElement.play();
          currentPlayer = mediaElement;
        }
      });
      
    } catch(e) {
      
    }
    return false;
  });
  $('.dload').each(function () { var href = $(this).attr('href'); $(this).attr('href', 'download.php?f=' + href); });
  $('.play').each(function(){
      $(this).attr("rel",$(this).closest('.message_buttons').next('.audio_player').attr('id'));
  });

  });
  $(function() {
    var links = $('.message_sharing a'),
        matchExp = /\[PAGEURL\]/,
        currentURL = location.href;

    links.each(function() {
        var currentHREF = $(this).attr('href');
        if (currentHREF.match(matchExp)) {
            $(this).attr('href',currentHREF.replace(matchExp,currentURL));
        }
    });

});
</script>

<div class="message_archive">
      <div class="message_archive_message">
      <div class="message_series_image" id="series-image"><img id="e9135b" class="cms-editable" src="/cms-assets/images/493461.engage-media.png?rand=0.5290789071980462" alt="" width="595" height="280" /></div>
      <div class="message_details">
        <div><h1 class="message_title cms-editable" id="title">ENGAGE</h1></div>
        <div class="series_description cms-editable-text" id="Series_desc">Everything hinges on relationships, but we must first engage.</div>
  

      </div><!-- end message_details-->
      </div><!-- message_archive_message -->
    </div><!-- message_archive -->
    
    
    
              


    <div class="message_archive cms-repeat" id="message-repeat">
<div class="message_archive_message">
<div class="media">
<h4 id="eb941c" class="message_info cms-editable"><strong>The Mud.&nbsp;Week 1<br /></strong>February 5, 2017, Pastor Jeremiah</h4>
<div class="message_description cms-editable" id="eef159">
<p>Join us as we discover the meaning of MUD.</p>
</div>
<div class="message_buttons">
<div class="message_sharing">
<ul class="message_sharing_links">
<li class="greyback_primary message_sharing_share">Share:</li>
<li class="message_sharing_facebook greyback_primary_accent"><a href="http://www.facebook.com/sharer.php?u=[PAGEURL]" target="_blank">F</a></li>
<li class="message_sharing_twitter greyback_primary_accent"><a href="http://twitter.com/home?status=[PAGEURL]" target="_blank">T</a></li>
<li class="message_sharing_email greyback_primary_accent"><a href="mailto:?">E</a></li>
</ul>
</div>
<div class="message_controls">
<ul class="message_control_links">
<li id="e793e8" class="message_control_listen greyback_primary_accent cms-editable"><a class="play" href="media/engage020517.mp3"><img id="ecaeb7" src="css/media/listen.jpg" alt="" width="79" height="24" /></a></li>
<li id="e9b9de" class="message_control_download greyback_primary_accent cms-editable"><a class="dload"><img id="e63338" src="css/media/download.jpg" alt="" width="98" height="24" /></a><img id="e729cc" src="css/media/notes.jpg" alt="" width="81" height="24" /><img id="e8dd2e" src="css/media/transcript.jpg" alt="" width="107" height="24" /></li>
</ul>
</div>
</div>
<div class="audio_player" id="e9e3f6"><audio controls="controls"></audio></div>
</div>
<!-- end media --></div>
<!-- message_archive_message --></div><div class="message_archive cms-repeat cms-previous-repeat-item-id-message-repeat" id="e3449d" title="">
<div class="message_archive_message">
<div class="media">
<h4 id="e16b24" class="message_info cms-editable"><strong>Marriage, The Gospel Is Counting On It.&nbsp;Week 2<br /></strong>February 12, 2017, Taylor Haley</h4>
<div class="message_description cms-editable" id="ec592b">
<p>The Gospel is counting on our Christ centered marriage to engage the world.</p>
</div>
<div class="message_buttons">
<div class="message_sharing">
<ul class="message_sharing_links">
<li class="greyback_primary message_sharing_share">Share:</li>
<li class="message_sharing_facebook greyback_primary_accent"><a href="http://www.facebook.com/sharer.php?u=[PAGEURL]" target="_blank">F</a></li>
<li class="message_sharing_twitter greyback_primary_accent"><a href="http://twitter.com/home?status=[PAGEURL]" target="_blank">T</a></li>
<li class="message_sharing_email greyback_primary_accent"><a href="mailto:?">E</a></li>
</ul>
</div>
<div class="message_controls">
<ul class="message_control_links">
<li id="ecbc02" class="message_control_listen greyback_primary_accent cms-editable"><a class="play" href="media/engage021217.mp3"><img id="e42967" src="css/media/listen.jpg" alt="" width="79" height="24" /></a></li>
<li id="e1b1fb" class="message_control_download greyback_primary_accent cms-editable"><a class="dload"><img id="e41288" src="css/media/download.jpg" alt="" width="98" height="24" /></a><img id="e8cdee" src="css/media/notes.jpg" alt="" width="81" height="24" /><img id="ed65d3" src="css/media/transcript.jpg" alt="" width="107" height="24" /></li>
</ul>
</div>
</div>
<div class="audio_player" id="e7d9ee"><audio controls="controls"></audio></div>
</div>
<!-- end media --></div>
<!-- message_archive_message --></div><div class="message_archive cms-repeat cms-previous-repeat-item-id-e3449d" id="e77942" title="">
<div class="message_archive_message">
<div class="media">
<h4 id="ead490" class="message_info cms-editable"><strong>Getting Our Hands Dirty, The Gospel Is Counting On It.&nbsp;Week 3<br /></strong>February 19, 2017, Dustin Smith</h4>
<div class="message_description cms-editable" id="eb721c">
<p>The Gospel is counting on our service.</p>
</div>
<div class="message_buttons">
<div class="message_sharing">
<ul class="message_sharing_links">
<li class="greyback_primary message_sharing_share">Share:</li>
<li class="message_sharing_facebook greyback_primary_accent"><a href="http://www.facebook.com/sharer.php?u=[PAGEURL]" target="_blank">F</a></li>
<li class="message_sharing_twitter greyback_primary_accent"><a href="http://twitter.com/home?status=[PAGEURL]" target="_blank">T</a></li>
<li class="message_sharing_email greyback_primary_accent"><a href="mailto:?">E</a></li>
</ul>
</div>
<div class="message_controls">
<ul class="message_control_links">
<li id="e4b380" class="message_control_listen greyback_primary_accent cms-editable"><a class="play" href="media/engage021917.mp3"><img id="ec87af" src="css/media/listen.jpg" alt="" width="79" height="24" /></a></li>
<li id="e2db4b" class="message_control_download greyback_primary_accent cms-editable"><a class="dload"><img id="e5bf87" src="css/media/download.jpg" alt="" width="98" height="24" /></a><img id="e1c618" src="css/media/notes.jpg" alt="" width="81" height="24" /><img id="eb505a" src="css/media/transcript.jpg" alt="" width="107" height="24" /></li>
</ul>
</div>
</div>
<div class="audio_player" id="e57901"><audio controls="controls"></audio></div>
</div>
<!-- end media --></div>
<!-- message_archive_message --></div><div class="message_archive cms-repeat cms-previous-repeat-item-id-e77942" id="e2aa91" title="">
<div class="message_archive_message">
<div class="media">
<h4 id="e7fc59" class="message_info cms-editable"><strong>Get Your Faith Fight On, The Gospel Is Counting On It.&nbsp;Week 4<br /></strong>February 26, 2017, Pastor Jeremiah</h4>
<div class="message_description cms-editable" id="e23917">
<p>The Gospel is counting on our faith fight.</p>
</div>
<div class="message_buttons">
<div class="message_sharing">
<ul class="message_sharing_links">
<li class="greyback_primary message_sharing_share">Share:</li>
<li class="message_sharing_facebook greyback_primary_accent"><a href="http://www.facebook.com/sharer.php?u=[PAGEURL]" target="_blank">F</a></li>
<li class="message_sharing_twitter greyback_primary_accent"><a href="http://twitter.com/home?status=[PAGEURL]" target="_blank">T</a></li>
<li class="message_sharing_email greyback_primary_accent"><a href="mailto:?">E</a></li>
</ul>
</div>
<div class="message_controls">
<ul class="message_control_links">
<li id="eb4c54" class="message_control_listen greyback_primary_accent cms-editable"><a class="play" href="media/engage022617.mp3"><img id="e454fe" src="css/media/listen.jpg" alt="" width="79" height="24" /></a></li>
<li id="ee10fd" class="message_control_download greyback_primary_accent cms-editable"><a class="dload"><img id="e24132" src="css/media/download.jpg" alt="" width="98" height="24" /></a><img id="e9b055" src="css/media/notes.jpg" alt="" width="81" height="24" /><img id="e514e7" src="css/media/transcript.jpg" alt="" width="107" height="24" /></li>
</ul>
</div>
</div>
<div class="audio_player" id="e695af"><audio controls="controls"></audio></div>
</div>
<!-- end media --></div>
<!-- message_archive_message --></div><!-- message_archive -->
    </div><!-- end c-8-->
            
                <div class="c-4 sidebar">
              
              
              
            </div><!-- end wrap -->
        </div><!-- end content -->
        
    <!-- Include Footer -->
    <div id="footer">
        <div class="wrap">
            <div class="footer-content">

              <div class="c-4">
                  <div class="widget widget-about">
                    
                        <h3 class="widget-title cms-editable" id="footer-title1"><a href="http://connectionpoint4u.com/contactpage.php"><span style="color: #00ff00;">CONTACT US</span></a></h3>
                        <div class="excerpt cms-editable" id="footer-text1">
<p><span style="font-size: medium;">If you have any questions about our church, or maybe you simply need prayer please click here.</span></p>
<p><span style="font-size: medium;">&nbsp;</span></p>
<p><span style="font-size: medium;">&nbsp;</span></p>
</div>    
                    </div><!-- end widget-about --> 
                </div>
                
                <div class="c-4">
              	     <div class="widget widget-about">
                 	 <h3 class="widget-title cms-editable" id="footer-title2"><strong><a href="location2014.php"><span style="color: #00ff00;">LOCATION</span></a></strong></h3>
                     
                        <div class="excerpt cms-editable" id="footer-text2">
<p><strong>Premier Parties LLC. 81 Knox Ct.<br /> Barbourville, KY 40906. <br /></strong></p>
<p><strong><span style="color: #00ff00;"><a title="Map of Barbourville, KY" href="https://mapsengine.google.com/map/edit?mid=zvFuqdkx4viw.kFFf35OTKBtA" target="_blank"><span style="color: #00ff00;">MAP</span></a></span>&nbsp;&nbsp;&nbsp;&nbsp; <span style="color: #00ff00;"><a title="Directions to Connection Point Church" href="https://maps.google.com/maps?daddr=Cr-1177Q,+Barbourville,+KY+40906.&amp;hl=en&amp;sll=37.208457,-82.710571&amp;sspn=4.125108,4.059448&amp;t=h&amp;mra=mdsmb&amp;disamb=1&amp;z=17" target="_blank"><span style="color: #00ff00;">DIRECTIONS</span></a></span><br /></strong></p>
</div>    
                     </div><!-- end widget-about -->  
                </div>
                
                <div class="c-4">
                 <div class="widget widget-about">
                 	 <h3 class="widget-title cms-editable" id="footer-title3"><span style="color: #00ff00;">SOCIAL MEDIA</span></h3>
                     
                       <div class="excerpt cms-editable" id="footer-text3">
<p><strong><a href="https://twitter.com/ConnectPoint4u" target="_blank"><img id="e1a4e2" src="https://lh3.ggpht.com/lSLM0xhCA1RZOwaQcjhlwmsvaIQYaP3c5qbDKCgLALhydrgExnaSKZdGa8S3YtRuVA=w300" alt="http://twitter.com" width="48" height="48" /></a>&nbsp; &nbsp;&nbsp;</strong><strong style="font-size: 12px; background-color: #202020;"><a style="font-size: 12px; color: #ffffff;" href="https://www.facebook.com/connectionpoint4u" target="_blank"><img id="e73973" style="margin-bottom: 2px;" src="https://en.facebookbrand.com/wp-content/uploads/2016/05/FB-fLogo-Blue-broadcast-2.png" alt="facebook.com" width="44" height="44" /></a>&nbsp; &nbsp;&nbsp;</strong><strong style="font-size: 12px;"><a href="https://www.instagram.com/connectionpoint4u" target="_blank"><img id="e2d2b5" src="/cms-assets/images/464444.igglyphfill.png" alt="instagram.com" width="45" height="45" /></a>&nbsp; &nbsp; &nbsp;&nbsp;</strong></p>
<p><strong><a title="YouTube Channel" href="https://www.youtube.com/channel/UCkQONmzujho4lbxIRxzWteQ/feed?view_as=public" target="_blank"><img id="ee2891" style="display: none !important;" title="YouTube Channel" src="/~connectp/cms-assets/images/980189.youtube.png" alt="YouTube Channel" width="48" height="48" /></a></strong></p>
<script type="text/javascript">// <![CDATA[
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-47042572-1', 'connectionpoint4u.com');
  ga('send', 'pageview');
// ]]></script>
</div>    
                     </div><!-- end widget-about -->  
                </div>
                </div>
                </div><!-- end wrap -->
                
                <div class="wrap">

                <br>
                <div class="c-6">
                      <a href="http://bridgeelement.com" target="_blank">Church Websites by Bridge Element</a>
		</div>
                  
        	</div><!-- end wrap -->
          
        </div><!-- end footer -->
        
         
    
    <!-- Include Google Tracker -->
    <!-- FOR THE CLIENT -->
<script type="text/javascript">
  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-xxxxxxx-x']);
  _gaq.push(['_trackPageview']);
  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();
</script>

<!-- FOR THE DASHBOARD -->
<script type="text/javascript">
  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-42406122-34']);
  _gaq.push(['_trackPageview']);
  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();
</script>

<script type="text/javascript">
  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-2565586-4']);
  _gaq.push(['_trackPageview']);
  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();
</script>  

</body>
</html>
