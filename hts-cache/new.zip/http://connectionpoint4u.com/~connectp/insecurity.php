 
 
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

  <title>INSECURITY</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <meta name="description" content="INSECURITY, a sermon series of Connection Point Church | Barbourville, KY" />
  <meta name="keywords" content="INSECURITY, Connection Point Church, Barbourville, KY" />
  <meta name="Robots" content="index, follow" />
        
    <!-- Favicon -->
  <link href="favicon.ico" type="image/x-icon" rel="shortcut icon">
    
    <!-- Include CSS 
        
</head>


<body class="home">  
    
    <!-- Include Logo and Menu -->
            
        
        
        <div id="content">
        
          <div class="wrap">
              <div class="c-8 divider">
              
<script type="text/javascript"> 
	
	var currentPlayer;
	$(function(){
	
	$('.play').click(function() {
		$('.player').hide();
		player_div = $(this).attr('rel');
		container = $('#'+player_div);
		container.fadeIn();
		player =  $('#'+player_div+' audio');
		player.attr('src',$(this).attr('href'));
		
		try {
			player.mediaelementplayer({
				audioWidth:container.width(),
				success:function(mediaElement,domObject) {
					mediaElement.play();
					currentPlayer = mediaElement;
				}
			});
			
		} catch(e) {
			
		}
		return false;
  });
  $('.dload').each(function () { var href = $(this).attr('href'); $(this).attr('href', 'download.php?f=' + href); });
  $('.play').each(function(){
      $(this).attr("rel",$(this).closest('.message_buttons').next('.audio_player').attr('id'));
  });

  });
  $(function() {
    var links = $('.message_sharing a'),
        matchExp = /\[PAGEURL\]/,
        currentURL = location.href;

    links.each(function() {
        var currentHREF = $(this).attr('href');
        if (currentHREF.match(matchExp)) {
            $(this).attr('href',currentHREF.replace(matchExp,currentURL));
        }
    });

}); 
</script>

<div class="message_archive">
			<div class="message_archive_message">
			<div class="message_series_image" id="series-image"><img id="e9135b" class="cms-editable" src="/cms-assets/images/466471.insecuritylarge.jpg?rand=0.9016699166651985" alt="" width="595" height="280" /></div>
			<div class="message_details">
				<div><h1 class="message_title cms-editable" id="title">INSECURITY</h1></div>
				<div class="series_description cms-editable-text" id="Series_desc"><span class="null">Hello my name is INSECURITY: There isn't a person on this earth that doesn't struggle in some way with insecurity. It could be in your appearance, in your financial situation, relationships, self-esteem, capabilities, your intellect, or maybe your faith where you find your greatest insecurity. This sermon series will help to answer how we can become secure where we are the most insecure.</span></div>
	

			</div><!-- end message_details-->
			</div><!-- message_archive_message -->
		</div><!-- message_archive -->
		
		
		
              


		<div class="message_archive cms-repeat" id="message-repeat">
<div class="message_archive_message">
<div class="media">
<h4 id="info" class="message_info cms-editable"><strong><span class="null">I AM NOT ASHAMED</span> | Insecurity Series | Week Four</strong><br />1-25-2015, Pastor Jeremiah Evans</h4>
<div class="message_description cms-editable" id="desc">
<p><span class="null"><span class="null"><span class="null">Shame can be so contagious that it infects every area of our life! BUT that is not what God desires for you. Listen in to learn a new way to view and respond to shame!</span></span></span></p>
</div>
<div class="message_buttons">
<div class="message_sharing">
<ul class="message_sharing_links">
<li class="greyback_primary message_sharing_share">Share:</li>
<li class="message_sharing_facebook greyback_primary_accent"><a href="http://www.facebook.com/sharer.php?u=[PAGEURL]" target="_blank">F</a></li>
<li class="message_sharing_twitter greyback_primary_accent"><a href="http://twitter.com/home?status=[PAGEURL]" target="_blank">T</a></li>
<li class="message_sharing_email greyback_primary_accent"><a href="mailto:?">E</a></li>
</ul>
</div>
<div class="message_controls">
<ul class="message_control_links">
<li id="listen" class="message_control_listen greyback_primary_accent cms-editable"><a class="play" href="media/Pastor-Jeremiah_1-25-2015_final.mp3"><img id="edc440" src="css/media/listen.jpg" alt="" width="79" height="24" /></a></li>
<li id="download" class="message_control_download greyback_primary_accent cms-editable"><a class="dload" href="media/Pastor-Jeremiah_1-25-2015_final.mp3"><img id="e18729" src="css/media/download.jpg" alt="" width="98" height="24" /></a></li>
</ul>
</div>
</div>
<div class="audio_player" id="play1243"><audio controls="controls"></audio></div>
</div>
<!-- end media --></div>
<!-- message_archive_message --></div><div class="message_archive cms-repeat cms-previous-repeat-item-id-message-repeat" id="e14b0f">
<div class="message_archive_message">
<div class="media">
<h4 id="edd01" class="message_info cms-editable"><strong><span class="null">FEAR FACTOR</span>&nbsp;| Insecurity Series | Week Three</strong><br />1-18-2015, Pastor Jeremiah Evans</h4>
<div class="message_description cms-editable" id="eb8cf1">
<p><span class="null"><span class="null">One of the most paralyzing elements of insecurity is FEAR! Fear has a tendency to speak over areas of our lives to keep us from living freely the way that God desires us to live. Listen in a learn how to fuel your courage to face your fears instead of fueling your fears!</span></span></p>
</div>
<div class="message_buttons">
<div class="message_sharing">
<ul class="message_sharing_links">
<li class="greyback_primary message_sharing_share">Share:</li>
<li class="message_sharing_facebook greyback_primary_accent"><a href="http://www.facebook.com/sharer.php?u=[PAGEURL]" target="_blank">F</a></li>
<li class="message_sharing_twitter greyback_primary_accent"><a href="http://twitter.com/home?status=[PAGEURL]" target="_blank">T</a></li>
<li class="message_sharing_email greyback_primary_accent"><a href="mailto:?">E</a></li>
</ul>
</div>
<div class="message_controls">
<ul class="message_control_links">
<li id="e4fc84" class="message_control_listen greyback_primary_accent cms-editable"><a class="play" href="media/Pastor-Jeremiah_1-18-2015_final.mp3"><img id="e51753" src="css/media/listen.jpg" alt="" width="79" height="24" /></a></li>
<li id="eccc16" class="message_control_download greyback_primary_accent cms-editable"><a class="dload" href="media/Pastor-Jeremiah_1-18-2015_final.mp3"><img id="e3375b" src="css/media/download.jpg" alt="" width="98" height="24" /></a></li>
</ul>
</div>
</div>
<div class="audio_player" id="edafba"><audio controls="controls"></audio></div>
</div>
<!-- end media --></div>
<!-- message_archive_message --></div><div class="message_archive cms-repeat cms-previous-repeat-item-id-message-repeat" id="ed308a">
<div class="message_archive_message">
<div class="media">
<h4 id="e72e4e" class="message_info cms-editable"><strong><span class="null">VOICES OF INSECURITY</span> | Insecurity Series | Week Two</strong><br />1-11-2015, Pastor Jeremiah Evans</h4>
<div class="message_description cms-editable" id="ef3488">
<p><span class="null">The enemy will use the voices of your history and past choices to inform your insecurity! If we could just understand and embrace that in spite of all of our imperfections that God still loves us and chooses to use us then we could live in freedom and empowered to serve Him more greatly!</span></p>
</div>
<div class="message_buttons">
<div class="message_sharing">
<ul class="message_sharing_links">
<li class="greyback_primary message_sharing_share">Share:</li>
<li class="message_sharing_facebook greyback_primary_accent"><a href="http://www.facebook.com/sharer.php?u=[PAGEURL]" target="_blank">F</a></li>
<li class="message_sharing_twitter greyback_primary_accent"><a href="http://twitter.com/home?status=[PAGEURL]" target="_blank">T</a></li>
<li class="message_sharing_email greyback_primary_accent"><a href="mailto:?">E</a></li>
</ul>
</div>
<div class="message_controls">
<ul class="message_control_links">
<li id="ed3808" class="message_control_listen greyback_primary_accent cms-editable"><a class="play" href="media/Pastor-Jeremiah_1-11-2015_final.mp3"><img id="e77a74" src="css/media/listen.jpg" alt="" width="79" height="24" /></a></li>
<li id="edf5ea" class="message_control_download greyback_primary_accent cms-editable"><a class="dload" href="media/Pastor-Jeremiah_1-11-2015_final.mp3"><img id="ed2aa0" src="css/media/download.jpg" alt="" width="98" height="24" /></a></li>
</ul>
</div>
</div>
<div class="audio_player" id="e436af"><audio controls="controls"></audio></div>
</div>
<!-- end media --></div>
<!-- message_archive_message --></div><!-- message_archive -->
		</div><!-- end c-8-->
            
                <div class="c-4 sidebar">
                    
                    <div class="widget widget-news-events">
                        
                        <h3 class="widget-title cms-editable" id="events-title">&nbsp;</h3>
                        <ul>
                            <li class="cms-repeat" id="events-repeat">
<h3 id="event-heading" class="title cms-editable"><a href="gameplan.php">&nbsp;</a></h3>
<div class="excerpt" id="event-content-div">
<p id="event-content" class="cms-editable">&nbsp;</p>
</div>
</li>
                            
                        </ul>
                        
                    </div><!-- end widget-news-events-->                       
                </div><!-- end sidebar -->
            </div><!-- end wrap -->
        </div><!-- end content -->
        
    <!-- Include Footer -->
        
    <!-- Include Google Tracker -->
         
	<script type="text/javascript" src="css/media/mediaelement-and-player.min.js"></script>
</body>
</html>
