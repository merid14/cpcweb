 
 
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

  <title>HIS BRAIN-HER BRAIN</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <meta name="description" content="HIS BRAIN-HER BRAIN, a sermon series of Connection Point Church | Barbourville, KY" />
  <meta name="keywords" content="HIS BRAIN-HER BRAIN, Connection Point Church, Barbourville, KY" />
  <meta name="Robots" content="index, follow" />
        
    <!-- Favicon -->
  <link href="favicon.ico" type="image/x-icon" rel="shortcut icon">
    
    <!-- Include CSS 
        
</head>


<body class="home">  
    
    <!-- Include Logo and Menu -->
            
        
        
        <div id="content">
        
          <div class="wrap">
              <div class="c-8 divider">
              
<script type="text/javascript"> 
	
	var currentPlayer;
	$(function(){
	
	$('.play').click(function() {
		$('.player').hide();
		player_div = $(this).attr('rel');
		container = $('#'+player_div);
		container.fadeIn();
		player =  $('#'+player_div+' audio');
		player.attr('src',$(this).attr('href'));
		
		try {
			player.mediaelementplayer({
				audioWidth:container.width(),
				success:function(mediaElement,domObject) {
					mediaElement.play();
					currentPlayer = mediaElement;
				}
			});
			
		} catch(e) {
			
		}
		return false;
  });
  $('.dload').each(function () { var href = $(this).attr('href'); $(this).attr('href', 'download.php?f=' + href); });
  $('.play').each(function(){
      $(this).attr("rel",$(this).closest('.message_buttons').next('.audio_player').attr('id'));
  });

  });
  $(function() {
    var links = $('.message_sharing a'),
        matchExp = /\[PAGEURL\]/,
        currentURL = location.href;

    links.each(function() {
        var currentHREF = $(this).attr('href');
        if (currentHREF.match(matchExp)) {
            $(this).attr('href',currentHREF.replace(matchExp,currentURL));
        }
    });

}); 
</script>

<div class="message_archive">
			<div class="message_archive_message">
			<div class="message_series_image" id="series-image"><img id="e9135b" class="cms-editable" src="/cms-assets/images/925253.hhblarge.jpg?rand=0.979690293771659" alt="" width="595" height="280" /></div>
			<div class="message_details">
				<div><h1 class="message_title cms-editable" id="title">HIS BRAIN - HER BRAIN</h1></div>
				<div class="series_description cms-editable-text" id="Series_desc">How is it that men and women can seem to be so similar yet so radically different? &ldquo;Honey&hellip;what&rsquo;s for dinner?&rdquo; &ldquo;Hey babe&hellip;does this dress make me look fat?&rdquo; &ldquo;Honey, I&rsquo;m ready to go???&rdquo; &ldquo;Hey babe, I&rsquo;m ready to go&rdquo; 30 minutes later &ldquo;Honey&hellip;what in the world are you doing???? I though we were leaving 30 min ago?&rdquo; HAHA! Oh the life of differences we have as men and women&hellip;yet in God&rsquo;s magnificent plan and design of all of our differences he has made us intentionally this way to bring balance and partnership into our lives. In this series we will have a blast learning that we most certainly are different&hellip;but yet divinely designed by God for one another. When we discover how it all works it makes life a bit easier to live out our God called purposes!!</div>
	

			</div><!-- end message_details-->
			</div><!-- message_archive_message -->
		</div><!-- message_archive -->
		
		
		
              


		<div class="message_archive cms-repeat" id="message-repeat">
<div class="message_archive_message">
<div class="media">
<h4 id="info" class="message_info cms-editable"><strong>HIS BRAIN - HER BRAIN | Part 2 | Different View; Same World</strong><br />2-8-2015, Pastor Jeremiah Evans</h4>
<div class="message_description cms-editable" id="desc">
<p>Isn&rsquo;t it funny how we live in the same house, we are living the same life together, as well as live in the same world yet we can see things completely different. This sermon deals with decoding our communication differences in the way we perceive, process, and the way we communicate with our world.</p>
</div>
<div class="message_buttons">
<div class="message_sharing">
<ul class="message_sharing_links">
<li class="greyback_primary message_sharing_share">Share:</li>
<li class="message_sharing_facebook greyback_primary_accent"><a href="http://www.facebook.com/sharer.php?u=[PAGEURL]" target="_blank">F</a></li>
<li class="message_sharing_twitter greyback_primary_accent"><a href="http://twitter.com/home?status=[PAGEURL]" target="_blank">T</a></li>
<li class="message_sharing_email greyback_primary_accent"><a href="mailto:?">E</a></li>
</ul>
</div>
<div class="message_controls">
<ul class="message_control_links">
<li id="listen" class="message_control_listen greyback_primary_accent cms-editable"><a class="play" href="media/Pastor-Jeremiah_2-8-2015_final.mp3"><img id="edc440" src="css/media/listen.jpg" alt="" width="79" height="24" /></a></li>
<li id="download" class="message_control_download greyback_primary_accent cms-editable"><a class="dload" href="media/Pastor-Jeremiah_2-8-2015_final.mp3"><img id="e18729" src="css/media/download.jpg" alt="" width="98" height="24" /></a></li>
</ul>
</div>
</div>
<div class="audio_player" id="play1243"><audio controls="controls"></audio></div>
</div>
<!-- end media --></div>
<!-- message_archive_message --></div><div class="message_archive cms-repeat cms-previous-repeat-item-id-message-repeat" id="ed768">
<div class="message_archive_message">
<div class="media">
<h4 id="e91b2d" class="message_info cms-editable"><strong>HIS BRAIN - HER BRAIN | Part 1 | Divinely Designed</strong><br />2-1-2015, Pastor Jeremiah Evans</h4>
<div class="message_description cms-editable" id="e5f52b">
<p>There are many who would say that men and women aren&rsquo;t so different from each other. There are others who seem to live on the other side of the fence and say that men and women are as different as night and day. So, are we equal? Are we really the same with just different physical attributes? I think God has shown us through science that although we are equally created in the image of God we are also divinely different for a purpose! Listen in to discover how and why!</p>
</div>
<div class="message_buttons">
<div class="message_sharing">
<ul class="message_sharing_links">
<li class="greyback_primary message_sharing_share">Share:</li>
<li class="message_sharing_facebook greyback_primary_accent"><a href="http://www.facebook.com/sharer.php?u=[PAGEURL]" target="_blank">F</a></li>
<li class="message_sharing_twitter greyback_primary_accent"><a href="http://twitter.com/home?status=[PAGEURL]" target="_blank">T</a></li>
<li class="message_sharing_email greyback_primary_accent"><a href="mailto:?">E</a></li>
</ul>
</div>
<div class="message_controls">
<ul class="message_control_links">
<li id="e2ffb9" class="message_control_listen greyback_primary_accent cms-editable"><a class="play" href="media/Pastor-Jeremiah_2-1-2015_final.mp3"><img id="e24025" src="css/media/listen.jpg" alt="" width="79" height="24" /></a></li>
<li id="eadf67" class="message_control_download greyback_primary_accent cms-editable"><a class="dload" href="media/Pastor-Jeremiah_2-1-2015_final.mp3"><img id="e4ca6a" src="css/media/download.jpg" alt="" width="98" height="24" /></a></li>
</ul>
</div>
</div>
<div class="audio_player" id="ebcb49"><audio controls="controls"></audio></div>
</div>
<!-- end media --></div>
<!-- message_archive_message --></div><!-- message_archive -->
		</div><!-- end c-8-->
            
                <div class="c-4 sidebar">
                    
                    <div class="widget widget-news-events">
                        
                        <h3 class="widget-title cms-editable" id="events-title">&nbsp;</h3>
                        <ul>
                            <li class="cms-repeat" id="events-repeat">
<h3 id="event-heading" class="title cms-editable"><a href="gameplan.php">&nbsp;</a></h3>
<div class="excerpt" id="event-content-div">
<p id="event-content" class="cms-editable">&nbsp;</p>
</div>
</li>
                            
                        </ul>
                        
                    </div><!-- end widget-news-events-->                       
                </div><!-- end sidebar -->
            </div><!-- end wrap -->
        </div><!-- end content -->
        
    <!-- Include Footer -->
        
    <!-- Include Google Tracker -->
         
	<script type="text/javascript" src="css/media/mediaelement-and-player.min.js"></script>
</body>
</html>
