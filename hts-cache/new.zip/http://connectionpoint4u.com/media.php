 

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

  <title>Media</title>
   <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <meta name="description" content="Thank you for checking out some of our sermons from our Sunday morning Worship experiences! We hope that God speaks to your heart through one of our messages. Media of Connection Point Church | Barbourvillle, KY" />
  <meta name="keywords" content="media, sermon series, connection point church, barbourville, KY" />
  <meta name="Robots" content="index, follow" />
        
    <!-- Favicon -->
  <link href="favicon.ico" type="image/x-icon" rel="shortcut icon">
    
    <!-- Include CSS -->
    <!-- DNS Prefetch -->
	<link rel="dns-prefetch" href="//ajax.googleapis.com">
	<link rel="dns-prefetch" href="//fonts.googleapis.com">
	<link rel="dns-prefetch" href="//cdn.mybridgeelement.com">

<!-- Design CSS -->
	<link rel="stylesheet" type="text/css" media="screen" href="http://cdn.mybridgeelement.com/_cornerstone/main.css" />
	<link rel="stylesheet" type="text/css" media="screen" href="http://cdn.mybridgeelement.com/_cornerstone/media.css" />
	<link rel="stylesheet" type="text/css" media="screen" href="http://cdn.mybridgeelement.com/_cornerstone/media/mediaelementplayer.min.css" />
	<link rel="stylesheet" type="text/css" media="screen" href="css/style.css" />
	<link rel="stylesheet" type="text/css" media="screen" href="/css/style.css" />
	<link href='http://fonts.googleapis.com/css?family=PT+Sans+Narrow:700' rel='stylesheet' type='text/css'>
	<link href='http://fonts.googleapis.com/css?family=Reenie+Beanie' rel='stylesheet' type='text/css'>
    
<!-- Scripts -->
	<script src="//ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
	<script>window.jQuery || document.write('<script src="js/jquery-1.6.2.min.js"><\/script>')</script>
	<!-- CMS:REMOVE -->
	<script type="text/javascript" src="http://cdn.mybridgeelement.com/js/jCarouselLite.js"></script>
	<script type="text/javascript" src="http://cdn.mybridgeelement.com/js/jquery.innerfade.js"></script>
	<!-- CMS:END-REMOVE -->
	<script type="text/javascript" src="http://cdn.mybridgeelement.com/js/main_cornerstone.js"></script> 
	<script type="text/javascript" src="http://cdn.mybridgeelement.com/js/modernizr-2.0.6.min.js"></script> 
 
<!-- Disqus ID -->


<!-- Folder Links -->
<script type="text/javascript">
var folder = 'public_html';
</script>
<script type="text/javascript">
if(folder != 'public_html') {
$(function() {
   $('a:not([href*=":"])').each(function() {
       var href = $(this).attr('href');
       $(this).attr('href', '../' + href);  
   });
});
}
</script>

<!-- Image Links -->
<script type="text/javascript">
$(function() {
$('.tag .each(function() {
   $('img .each(function() {
       var href = $(this).attr('href');
       $(this).attr('href', '(dynRoot()' + href);  
   });
  }); 
});
</script>
<style type="text/css">
  
    #content .wrap {
	width: 1000px;
	}
    </style>
    
</head>

<body class="home">  
      
    <!-- Include Logo and Menu -->
    <div id="topbar"></div>
<div id="header">
	
            <div class="wrap">
            
                <h1 class="logo">
                    <a href="index.php">
                        <img src="/cms-assets/zoom-cropped-images/464535_165_logo-image.png?rand=0.27698214851389014" class="cms-editable" id="logo-image" width="400" height="101"  alt="" />
                    </a>
                </h1>
                
                <h3 class="header-title cms-editable" id="header-title"><span style="color: #00ff00;"><strong><br />Getting Connected&hellip;<br />Changing Lives...<br />Building Community...<br />One Life At A Time!!!<br /></strong></span> <script type="text/javascript">// <![CDATA[
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-96551914-1', 'auto');
  ga('send', 'pageview');
// ]]></script></h3>
                <div class="cms-navigation" id="main-navigation">                        <ul class="dd-menu"> 
<li>
<a href="index.php" class="dd-submenu-title">HOME</a>
</li>
<li>
<a href="#" class="dd-submenu-title">NEW HERE</a>
<ul>

<li class="arrow"></li>
<li><a href="whattoexpect.php">Sunday Service</a></li>
<li><a href="staff.php">Leadership</a></li>
<li><a href="beliefs.php">Beliefs</a></li>
<li><a href="location2014.php">Location</a></li>
<li><a href="/kids.php">Kids</a></li>
<li><a href="/~connectp/smallgroups.php">Connect Groups</a></li>
<li><a href="vision.php">Vision and Values</a></li>
</ul>
</li>
<li>
<a href="#" class="dd-submenu-title">NEXT STEPS</a>
<ul>

<li class="arrow"></li>
<li><a href="smallgroups.php">Connect Groups</a></li>
<li><a href="salvation.php">Salvation</a></li>
<li><a href="baptism.php">Baptism</a></li>
<li><a href="/~connectp/serving.php">Serving</a></li>
</ul>
</li>
<li>
<a href="media.php" class="dd-submenu-title">MEDIA</a>
</li>
<li>
<a href="contactpage.php" class="dd-submenu-title">CONTACT US</a>
</li>
<li>
<a href="http://www.mybridgeelementgiving.com/dl/?uid=connpob296" class="dd-submenu-title">GIVE</a>
</li>
<li>
<a href="/~connectp/takesonetonoone.php" class="dd-submenu-title">LISTEN NOW!</a>
</li>
</ul>

                    </div><!-- end main-navigation-->                
                

            </div><!-- end wrap -->
</div><!-- end header -->        
        
        
        <div id="content">
        
          <div class="wrap">
              
              <ul class="portfolio-menu archive-image">
              
                  <li class="c-4 four-column cms-repeat" id="slide1"><a id="e13866" class="cms-editable" title="We can't stay here" href="http://connectionpoint4u.com/~connectp/wecan'tstayhere.php"><img id="e8fb9e" class="cms-editable" src="/cms-assets/zoom-cropped-images/464544_95_e8fb9e.jpg?rand=0.4592115360219622" alt="" width="300" height="168" /></a>
<h4 id="e5e43d" class="title cms-editable">SERMON SERIES - We can't stay here</h4>
</li><li id="e2d726" class="c-4 four-column cms-repeat cms-previous-repeat-item-id-slide1"><a id="ee1868" class="cms-editable" title="" href="http://connectionpoint4u.com/~connectp/make-war.php"><img id="eef41f" class="cms-editable" src="/cms-assets/zoom-cropped-images/464544_94_e8fb9e.jpg?rand=0.716783840582154" alt="" width="300" height="168" /></a>
<h4 id="e40026" class="title cms-editable">SERMON SERIES - Make War!</h4>
</li><li id="ec6016" class="c-4 four-column cms-repeat cms-previous-repeat-item-id-slide1"><a id="e65580" class="cms-editable" title="" href="http://connectionpoint4u.com/~connectp/itsoktonotbeok.php"><img id="ecf2ac" class="cms-editable" src="/cms-assets/images/966903.itsok.png?rand=0.2583724577037714" alt="" width="300" height="168" /></a>
<h4 id="eed22c" class="title cms-editable">SERMON SERIES - It's Ok to Not Be Ok.</h4>
</li><li id="e17600" class="c-4 four-column cms-repeat cms-previous-repeat-item-id-slide1"><a id="eda91d" class="cms-editable" title="" href="http://connectionpoint4u.com/~connectp/ilovethe90s.php"><img id="e9f556" class="cms-editable" src="/cms-assets/images/178293.90s.jpg?rand=0.42578721479602444" alt="" width="300" height="168" /></a>
<h4 id="ece3b4" class="title cms-editable">SERMON SERIES - I Love The 90's</h4>
</li><li id="eda43d" class="c-4 four-column cms-repeat cms-previous-repeat-item-id-slide1"><a id="e780e6" class="cms-editable" title="" href="http://connectionpoint4u.com/~connectp/engage.php"><img id="eae0a1" class="cms-editable" src="/cms-assets/images/493461.engage-media.png?rand=0.9978739216452188" alt="" width="300" height="168" /></a>
<h4 id="e1360f" class="title cms-editable">SERMON SERIES - ENGAGE!</h4>
</li><li id="ea4c84" class="c-4 four-column cms-repeat cms-previous-repeat-item-id-slide1"><a id="ead3e3" class="cms-editable" title="" href="http://connectionpoint4u.com/~connectp/takesonetonoone.php"><img id="e9ba9c" class="cms-editable" src="/cms-assets/zoom-cropped-images/464544_88_e8fb9e.jpg?rand=0.8776388144182055" alt="" width="300" height="168" /></a>
<h4 id="edc527" class="title cms-editable">SERMON SERIES - Takes One To No One</h4>
</li><li id="e8d944" class="c-4 four-column cms-repeat cms-previous-repeat-item-id-slide1"><a id="ec2d96" class="cms-editable" title="" href="http://connectionpoint4u.com/~connectp/newyears2017.php"><img id="edc72b" class="cms-editable" src="/cms-assets/zoom-cropped-images/464544_89_edc72b.png?rand=0.8556788910825646" alt="" width="300" height="168" /></a>
<h4 id="e5c230" class="title cms-editable">2017 Night of Worship</h4>
</li><li id="e701bf" class="c-4 four-column cms-repeat cms-previous-repeat-item-id-slide1"><a id="ed219f" class="cms-editable" title="" href="http://connectionpoint4u.com/~connectp/breathe.php"><img id="e689c2" class="cms-editable" src="/cms-assets/zoom-cropped-images/464544_83_e8fb9e.png?rand=0.4648767011796342" alt="" width="300" height="168" /></a>
<h4 id="e87ed2" class="title cms-editable">SERMON SERIES - BREATHE</h4>
</li><li id="e2df4f" class="c-4 four-column cms-repeat cms-previous-repeat-item-id-slide1"><a id="ea517f" class="cms-editable" title="" href="http://connectionpoint4u.com/~connectp/detox.php"><img id="ef2a38" class="cms-editable" src="/cms-assets/zoom-cropped-images/464544_81_e13866670f24.jpg?rand=0.9364829967062052" alt="" width="300" height="168" /></a>
<h4 id="e4acca" class="title cms-editable">SERMON SERIES - DETOX</h4>
</li><li id="e62c5f" class="c-4 four-column cms-repeat cms-previous-repeat-item-id-slide1"><a id="e78123" class="cms-editable" title="" href="http://connectionpoint4u.com/~connectp/weare.php"><img id="e2326b" class="cms-editable" src="/cms-assets/zoom-cropped-images/464544_77_e8fb9e.png?rand=0.4068142685900294" alt="" width="300" height="168" /></a>
<h4 id="ead4dc" class="title cms-editable">SERMON SERIES - WE ARE</h4>
</li><li id="e5dd5b" class="c-4 four-column cms-repeat cms-previous-repeat-item-id-slide1"><a id="eb46de" class="cms-editable" title="" href="http://connectionpoint4u.com/~connectp/runningwithgiants.php"><img id="ef0bf7" class="cms-editable" src="/cms-assets/zoom-cropped-images/464544_75_e8fb9e.jpg?rand=0.9525606587176567" alt="" width="300" height="168" /></a>
<h4 id="e5574b" class="title cms-editable">SERMON SERIES - GIANTS</h4>
</li><li id="e1dd97" class="c-4 four-column cms-repeat cms-previous-repeat-item-id-slide1"><a id="e3c359" class="cms-editable" title="" href="http://connectionpoint4u.com/~connectp/audaciousfaith.php"><img id="e117c" class="cms-editable" src="/cms-assets/zoom-cropped-images/464544_72_e8fb9e.jpg?rand=0.7423904346370265" alt="" width="300" height="168" /></a>
<h4 id="e750a6" class="title cms-editable">SERMON SERIES - AUDACIOUS FAITH</h4>
</li><li id="e9788e" class="c-4 four-column cms-repeat cms-previous-repeat-item-id-slide1"><a id="e1556a" class="cms-editable" title="" href="http://connectionpoint4u.com/~connectp/christianatheist.php"><img id="e98841" class="cms-editable" src="/cms-assets/zoom-cropped-images/464544_71_e8fb9e.jpg?rand=0.9528564312629792" alt="" width="300" height="168" /></a>
<h4 id="e8889f" class="title cms-editable">SERMON SERIES - CHRISTIAN ATHEIST</h4>
</li><li id="e72fd1" class="c-4 four-column cms-repeat cms-previous-repeat-item-id-slide1"><a id="ea49e7" class="cms-editable" title="" href="http://connectionpoint4u.com/prayerandfasting.php"><img id="ea7fb" class="cms-editable" src="/cms-assets/zoom-cropped-images/587345_11_e8fb9e.jpg?rand=0.29024482351068376" alt="" width="300" height="168" /></a>
<h4 id="e8dca5" class="title cms-editable">SERMON SERIES - PRAYER</h4>
</li><li id="e52eb2" class="c-4 four-column cms-repeat cms-previous-repeat-item-id-slide1"><a id="ebc553" class="cms-editable" title="" href="http://connectionpoint4u.com/stuck.php"><img id="e6b008" class="cms-editable" src="/cms-assets/zoom-cropped-images/464544_67_e8fb9e.jpg?rand=0.7922904202778902" alt="" width="300" height="168" /></a>
<h4 id="ed41ac" class="title cms-editable">SERMON SERIES - STUCK</h4>
</li><li id="e2de52" class="c-4 four-column cms-repeat cms-previous-repeat-item-id-slide1"><a id="e1cf2c" class="cms-editable" title="" href="http://connectionpoint4u.com/change.php"><img id="e2c87e" class="cms-editable" src="/cms-assets/images/809419.change.series.jpg?rand=0.12593438502695398" alt="" width="300" height="168" /></a>
<h4 id="edd1f4" class="title cms-editable">SERMON SERIES - CHANGE</h4>
</li><li id="ee321a" class="c-4 four-column cms-repeat cms-previous-repeat-item-id-e2de52"><a id="e3dd8e" class="cms-editable" title="" href="http://connectionpoint4u.com/~connectp/what-on-earth.php"><img id="e3c6e2" class="cms-editable" src="/cms-assets/zoom-cropped-images/464544_65_e2c87e.jpg?rand=0.08031983627602968" alt="" width="300" height="168" /></a>
<h4 id="e687d2" class="title cms-editable">SERMON SERIES - FOLLOW ME</h4>
</li><li id="e4c401" class="c-4 four-column cms-repeat cms-previous-repeat-item-id-slide1" style="opacity: 1;" title=""><a id="e28781" class="cms-editable" href="what-on-earth.php"><img id="e823f5" class="cms-editable" src="/cms-assets/images/404042.woeaihfsmall.jpg?rand=0.02467038016642492" alt="" width="300" height="168" /></a>
<h4 id="e22f19" class="title cms-editable">WHAT ON EARTH AM I HERE FOR?</h4>
</li><li id="e5cc8c" class="c-4 four-column cms-repeat cms-previous-repeat-item-id-slide1"><a id="ec9328" class="cms-editable" href="missional_maddness.php"><img id="e78af1" class="cms-editable" src="/cms-assets/images/232934.mmsmall.jpg?rand=0.5094764462284018" alt="" width="300" height="168" /></a>
<h4 id="e7a89f" class="title cms-editable">Sermon Series - Missional Madness</h4>
</li><li id="e9a450" class="c-4 four-column cms-repeat cms-previous-repeat-item-id-slide1"><a id="e71e9e" class="cms-editable" href="hbhb.php"><img id="e296a5" class="cms-editable" src="/cms-assets/images/511518.hhbsmall.jpg?rand=0.011058628248390101" alt="" width="300" height="168" /></a>
<h4 id="e5470c" class="title cms-editable">Sermon Series - HIS BRAIN - HER BRAIN</h4>
</li><li id="eea650" class="c-4 four-column cms-repeat cms-previous-repeat-item-id-slide1"><a id="e6689d" class="cms-editable" href="insecurity.php"><img id="e40c37" class="cms-editable" src="/cms-assets/images/373312.insecuritysmall.jpg?rand=0.08657525727977167" alt="" width="300" height="168" /></a>
<h4 id="e198a6" class="title cms-editable">Sermon Series - Insecurity</h4>
</li><li id="e871df" class="c-4 four-column cms-repeat cms-previous-repeat-item-id-slide1"><a id="e5fbf" class="cms-editable" href="christmas-culture.php"><img id="eda067" class="cms-editable" src="/cms-assets/images/638541.christmassmall.jpg?rand=0.20021731639165652" alt="" width="300" height="168" /></a>
<h4 id="e62371" class="title cms-editable">Sermon Series - Christmas Culture</h4>
</li><li id="e70331" class="c-4 four-column cms-repeat cms-previous-repeat-item-id-slide1"><a id="e42f42" class="cms-editable" href="remember-when.php"><img id="e16c71" class="cms-editable" src="/~connectp/cms-assets/images/571872.remembersmall.jpg?rand=0.3209915593521522" alt="" width="300" height="168" /></a>
<h4 id="e4464" class="title cms-editable">Sermon Series - Remember When</h4>
</li><li id="e508a1" class="c-4 four-column cms-repeat cms-previous-repeat-item-id-slide1"><a id="e93249" class="cms-editable" href="in-the-meantime.php"><img id="e56c16" class="cms-editable" src="/~connectp/cms-assets/images/520450.itmsmall.jpg?rand=0.8221047838064198" alt="" width="300" height="168" /></a>
<h4 id="ebf94e" class="title cms-editable">Sermon Series - In the Meantime</h4>
</li><li id="ec8688" class="c-4 four-column cms-repeat cms-previous-repeat-item-id-slide1"><a id="e451f1" class="cms-editable" href="mission-impossible.php"><img id="e855f4" class="cms-editable" src="/~connectp/cms-assets/images/786896.mismall.jpg?rand=0.831035251112878" alt="" width="300" height="168" /></a>
<h4 id="ead49e" class="title cms-editable">Sermon Series - Mission Impossible</h4>
</li><li id="eecb46" class="c-4 four-column cms-repeat cms-previous-repeat-item-id-slide1"><a id="ee49f1" class="cms-editable" href="soap.php"><img id="e592d7" class="cms-editable" src="/~connectp/cms-assets/images/457394.soapsmall.jpg?rand=0.9766539722610524" alt="" width="300" height="168" /></a>
<h4 id="e1b2f4" class="title cms-editable">Sermon Series - SOAP</h4>
</li><li id="e69af1" class="c-4 four-column cms-repeat cms-previous-repeat-item-id-slide1"><a id="eddbaf" class="cms-editable" href="freedom.php"><img id="e127bf" class="cms-editable" src="/~connectp/cms-assets/images/746696.freedomsmall.jpg?rand=0.3249750640402832" alt="" width="300" height="168" /></a>
<h4 id="e732eb" class="title cms-editable">Sermon Series - Freedom</h4>
</li><li id="e1e2c7" class="c-4 four-column cms-repeat cms-previous-repeat-item-id-slide1"><a id="e96d5" class="cms-editable" href="godis.php"><img id="efe45" class="cms-editable" src="/~connectp/cms-assets/images/977373.godisenough-small.jpg?rand=0.13633628370334583" alt="" width="300" height="168" /></a>
<h4 id="eb3dc1" class="title cms-editable">Sermon Series - God Is . . .</h4>
</li><li id="eb7f9a" class="c-4 four-column cms-repeat cms-previous-repeat-item-id-slide1"><a id="ed6735" class="cms-editable" href="money_talks.php"><img id="ef0ec5" class="cms-editable" src="/~connectp/cms-assets/images/517990.moneytalkssmall.jpg?rand=0.15546425056680646" alt="" width="300" height="168" /></a>
<h4 id="ef3842" class="title cms-editable">Sermon Series - Money Talks</h4>
</li><li id="ede37f" class="c-4 four-column cms-repeat cms-previous-repeat-item-id-slide1" title=""><a id="e5d5d4" class="cms-editable" href="gods-not-dead.php"><img id="e27adb" class="cms-editable" src="/~connectp/cms-assets/images/822957.gods-not-deadsmall.jpg?rand=0.7508271503003336" alt="" width="300" height="168" /></a>
<h4 id="e1b39" class="title cms-editable">Message - God's Not Dead</h4>
</li><li id="e349e7" class="c-4 four-column cms-repeat cms-previous-repeat-item-id-slide1"><a id="ed640d" class="cms-editable" href="invitation.php"><img id="edcb99" class="cms-editable" src="/~connectp/cms-assets/images/863312.invitationsmall.jpg?rand=0.14281011236412133" alt="" width="300" height="168" /></a>
<h4 id="ed440b" class="title cms-editable">Message on INVITATION</h4>
</li><li id="e99ae" class="c-4 four-column cms-repeat cms-previous-repeat-item-id-slide1"><a id="e3a361" class="cms-editable" href="life-hype.php"><img id="e7013" class="cms-editable" src="/~connectp/cms-assets/images/736204.life-hype.jpg?rand=0.17118485032093172" alt="" width="300" height="168" /></a>
<h4 id="ed2bff" class="title cms-editable">Sermon series "LIFE-HYPE" <br />Leadership Team</h4>
</li><li id="e18a60" class="c-4 four-column cms-repeat cms-previous-repeat-item-id-slide1"><a id="e4b592" class="cms-editable" href="broken.php"><img id="e69a25" class="cms-editable" src="/~connectp/cms-assets/images/271127.broken-346x146.jpg?rand=0.9912494643693027" alt="" width="300" height="168" /></a>
<h4 id="e6052e" class="title cms-editable">Sermon Series "BROKEN"<br />Pastor Jeremiah</h4>
</li><li id="e9b97c" class="c-4 four-column cms-repeat cms-previous-repeat-item-id-slide1" title=""><a id="e82de2" class="cms-editable" href="noresolutions.php"><img id="e40ae3" class="cms-editable" src="/~connectp/cms-assets/images/26900.noresolutions.jpg?rand=0.8017159095956423" alt="" width="300" height="168" /></a>
<h4 id="e687a5" class="title cms-editable">Sermon Series "NO RESOLUTIONS"<br />Pastor &amp; Staff</h4>
</li><li id="e768c4" class="c-4 four-column cms-repeat cms-previous-repeat-item-id-slide1"><a id="e4403a" class="cms-editable" href="proof.php"><img id="e9b5b" class="cms-editable" src="/~connectp/cms-assets/images/159613.proof.eyeglass.jpg?rand=0.584566297262298" alt="" width="300" height="168" /></a>
<h4 id="e2fc94" class="title cms-editable">Sermon Series "PROOF"<br />Pastor Jeremiah</h4>
</li><li id="e74cb4" class="c-4 four-column cms-repeat cms-previous-repeat-item-id-slide1"><a id="e2e45e" class="cms-editable" href="connect.php"><img id="e529aa" class="cms-editable" src="/~connectp/cms-assets/images/69177.connect.jpg?rand=0.3529503321824452" alt="" width="300" height="168" /></a>
<h4 id="e60b4" class="title cms-editable">Sermon Series "CONNECT"<br />Pastor Jeremiah</h4>
</li><li id="e7d3cc" class="c-4 four-column cms-repeat cms-previous-repeat-item-id-e74cb4"><a id="ec1d86" class="cms-editable" title="starts with you" href="media/91513sermon.mp3"><img id="ea1984" class="cms-editable" src="/~connectp/cms-assets/images/44248.startswu.climb.jpg?rand=0.2612972968074991" alt="" width="300" height="168" /></a>
<h4 id="ebd640" class="title cms-editable">1ST PREVIEW SERVICE&nbsp;(listen now)&nbsp;<br />Sept. 15th with Pastor Jeremiah<br />"It Starts With You"</h4>
</li><li id="ee4728" class="c-4 four-column cms-repeat cms-previous-repeat-item-id-e7d3cc"><a id="e6174e" class="cms-editable" title="Future is Forward" href="media/sermon91313.mp3"><img id="ea9913" class="cms-editable" src="/~connectp/cms-assets/images/991135.yourfutureisforward.jpg?rand=0.8568008838963315" alt="" width="300" height="168" /></a>
<h4 id="eaa382" class="title cms-editable"><a href="media/09132013.mp3">2ND PREVIEW SERVICE coming soon</a><br /><a href="media/09132013.mp3">OCT 13TH with Pastor Jeremiah</a></h4>
</li><li id="e39851" class="c-4 four-column cms-repeat cms-previous-repeat-item-id-ee4728" title=""><a id="e9500c" class="cms-editable" href="leadersconnectcenter.php"><img id="e9f31b" class="cms-editable" src="/~connectp/cms-assets/images/521920.leadersconnect.jpg?rand=0.5779386251603184" alt="" width="300" height="168" /></a>
<h4 id="ee5e2f" class="title cms-editable">Leader's Connect Training Center</h4>
</li>
                    
                    
                    </ul>
              
              
              
            </div><!-- end wrap -->
        </div><!-- end content -->
        
    <!-- Include Footer -->
    <div id="footer">
        <div class="wrap">
            <div class="footer-content">

              <div class="c-4">
                  <div class="widget widget-about">
                    
                        <h3 class="widget-title cms-editable" id="footer-title1"><a href="http://connectionpoint4u.com/contactpage.php"><span style="color: #00ff00;">CONTACT US</span></a></h3>
                        <div class="excerpt cms-editable" id="footer-text1">
<p><span style="font-size: medium;">If you have any questions about our church, or maybe you simply need prayer please click here.</span></p>
<p><span style="font-size: medium;">&nbsp;</span></p>
<p><span style="font-size: medium;">&nbsp;</span></p>
</div>    
                    </div><!-- end widget-about --> 
                </div>
                
                <div class="c-4">
              	     <div class="widget widget-about">
                 	 <h3 class="widget-title cms-editable" id="footer-title2"><strong><a href="location2014.php"><span style="color: #00ff00;">LOCATION</span></a></strong></h3>
                     
                        <div class="excerpt cms-editable" id="footer-text2">
<p><strong>Premier Parties LLC. 81 Knox Ct.<br /> Barbourville, KY 40906. <br /></strong></p>
<p><strong><span style="color: #00ff00;"><a title="Map of Barbourville, KY" href="https://mapsengine.google.com/map/edit?mid=zvFuqdkx4viw.kFFf35OTKBtA" target="_blank"><span style="color: #00ff00;">MAP</span></a></span>&nbsp;&nbsp;&nbsp;&nbsp; <span style="color: #00ff00;"><a title="Directions to Connection Point Church" href="https://maps.google.com/maps?daddr=Cr-1177Q,+Barbourville,+KY+40906.&amp;hl=en&amp;sll=37.208457,-82.710571&amp;sspn=4.125108,4.059448&amp;t=h&amp;mra=mdsmb&amp;disamb=1&amp;z=17" target="_blank"><span style="color: #00ff00;">DIRECTIONS</span></a></span><br /></strong></p>
</div>    
                     </div><!-- end widget-about -->  
                </div>
                
                <div class="c-4">
                 <div class="widget widget-about">
                 	 <h3 class="widget-title cms-editable" id="footer-title3"><span style="color: #00ff00;">SOCIAL MEDIA</span></h3>
                     
                       <div class="excerpt cms-editable" id="footer-text3">
<p><strong><a href="https://twitter.com/ConnectPoint4u" target="_blank"><img id="e1a4e2" src="https://lh3.ggpht.com/lSLM0xhCA1RZOwaQcjhlwmsvaIQYaP3c5qbDKCgLALhydrgExnaSKZdGa8S3YtRuVA=w300" alt="http://twitter.com" width="48" height="48" /></a>&nbsp; &nbsp;&nbsp;</strong><strong style="font-size: 12px; background-color: #202020;"><a style="font-size: 12px; color: #ffffff;" href="https://www.facebook.com/connectionpoint4u" target="_blank"><img id="e73973" style="margin-bottom: 2px;" src="https://en.facebookbrand.com/wp-content/uploads/2016/05/FB-fLogo-Blue-broadcast-2.png" alt="facebook.com" width="44" height="44" /></a>&nbsp; &nbsp;&nbsp;</strong><strong style="font-size: 12px;"><a href="https://www.instagram.com/connectionpoint4u" target="_blank"><img id="e2d2b5" src="/cms-assets/images/464444.igglyphfill.png" alt="instagram.com" width="45" height="45" /></a>&nbsp; &nbsp; &nbsp;&nbsp;</strong></p>
<p><strong><a title="YouTube Channel" href="https://www.youtube.com/channel/UCkQONmzujho4lbxIRxzWteQ/feed?view_as=public" target="_blank"><img id="ee2891" style="display: none !important;" title="YouTube Channel" src="/~connectp/cms-assets/images/980189.youtube.png" alt="YouTube Channel" width="48" height="48" /></a></strong></p>
<script type="text/javascript">// <![CDATA[
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-47042572-1', 'connectionpoint4u.com');
  ga('send', 'pageview');
// ]]></script>
</div>    
                     </div><!-- end widget-about -->  
                </div>
                </div>
                </div><!-- end wrap -->
                
                <div class="wrap">

                <br>
                <div class="c-6">
                      <a href="http://bridgeelement.com" target="_blank">Church Websites by Bridge Element</a>
		</div>
                  
        	</div><!-- end wrap -->
          
        </div><!-- end footer -->
        
           
    <!-- Include Google Tracker -->
    <!-- FOR THE CLIENT -->
<script type="text/javascript">
  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-xxxxxxx-x']);
  _gaq.push(['_trackPageview']);
  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();
</script>

<!-- FOR THE DASHBOARD -->
<script type="text/javascript">
  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-42406122-34']);
  _gaq.push(['_trackPageview']);
  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();
</script>

<script type="text/javascript">
  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-2565586-4']);
  _gaq.push(['_trackPageview']);
  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();
</script>
</body>
</html>
